# Graph Report - FaceSentinel - copia  (2026-09-12)

## Corpus Check
- 64 files · ~36,359 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 634 nodes · 886 edges · 62 communities (53 shown, 9 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 16 edges (avg confidence: 0.92)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `1bd809de`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- endpoints.py
- image_processing.py
- devDependencies
- test_api.py
- dependencies
- App.tsx
- storage.py
- compilerOptions
- compilerOptions
- physical_access_authenticate
- What You Must Do When Invoked
- security.py
- face_recognition.py
- remove_face
- get_device_by_token
- is_blockchain_available
- log_authentication
- get_contract_info
- comprehensive_liveness_check
- base64_to_image
- deploy.py
- FaceSentinel 🛡️🔗
- Ponytail
- websocket_liveness
- card.tsx
- test_recognition.py
- React + TypeScript + Vite
- migrate_device_tokens.py
- clear_biometrics.py
- context7.md
- rules/graphify.md
- ponytail.md
- workflows/graphify.md
- TestAuthentication
- logging_config.py
- crop_face
- button.tsx
- tabs.tsx
- reset_db.py
- input.tsx
- label.tsx
- tsconfig.json
- TestRegistration
- BlinkTracker
- TestBlockchain
- TestHealth
- config.py
- create_access_token
- get_current_user

## God Nodes (most connected - your core abstractions)
1. `compilerOptions` - 18 edges
2. `compilerOptions` - 18 edges
3. `base64_to_image()` - 15 edges
4. `physical_access_authenticate()` - 14 edges
5. `is_blockchain_available()` - 14 edges
6. `comprehensive_liveness_check()` - 12 edges
7. `What You Must Do When Invoked` - 12 edges
8. `websocket_liveness()` - 11 edges
9. `get_user_by_id()` - 11 edges
10. `/graphify` - 11 edges

## Surprising Connections (you probably didn't know these)
- `admin_headers()` --calls--> `create_access_token()`  [EXTRACTED]
  tests/test_api.py → app/core/security.py
- `create_test_users()` --calls--> `hash_client_secret()`  [EXTRACTED]
  create_test_users.py → app/core/security.py
- `websocket_liveness()` --uses--> `BlinkTracker`  [INFERRED]
  app/api/endpoints.py → app/services/liveness.py
- `physical_access_authenticate()` --uses--> `M2MAuthRequest`  [INFERRED]
  app/api/endpoints.py → app/api/schemas.py
- `physical_access_authenticate()` --indirect_call--> `log_authentication()`  [INFERRED]
  app/api/endpoints.py → app/services/blockchain.py

## Import Cycles
- None detected.

## Communities (62 total, 9 thin omitted)

### Community 0 - "endpoints.py"
Cohesion: 0.05
Nodes (67): add_device_acl(), authenticate_by_password(), authenticate_user(), blockchain_status(), change_my_password(), enroll_my_biometrics(), get_device_acl(), get_my_client_app() (+59 more)

### Community 1 - "image_processing.py"
Cohesion: 0.08
Nodes (30): general_exception_handler(), Request, Captura errores de validación y retorna un 400 limpio., Captura errores inesperados y retorna un 500 con información útil., value_error_handler(), align_face(), assess_image_quality(), decode_base64_image() (+22 more)

### Community 2 - "devDependencies"
Cohesion: 0.06
Nodes (34): eslint, @eslint/js, eslint-plugin-react-hooks, eslint-plugin-react-refresh, devDependencies, eslint, @eslint/js, eslint-plugin-react-hooks (+26 more)

### Community 3 - "test_api.py"
Cohesion: 0.28
Nodes (8): admin_headers(), client(), fixture, test_api.py — Tests de integración para los endpoints de la API Usa FastAPI…, Crea un cliente de prueba de FastAPI., Genera una imagen de prueba en Base64., Crea token JWT con rol admin para pruebas autorizadas., sample_image_base64()

### Community 4 - "dependencies"
Cohesion: 0.07
Nodes (29): axios, class-variance-authority, clsx, dependencies, axios, class-variance-authority, clsx, lucide-react (+21 more)

### Community 5 - "App.tsx"
Cohesion: 0.10
Nodes (17): App(), AccessControlView(), ACLRule, IoTDevice, UserRecord, AdminPanel(), AuditLog, Client (+9 more)

### Community 6 - "storage.py"
Cohesion: 0.06
Nodes (42): Any, get_devices(), list_oauth_clients(), list_users(), Lista todos los clientes OAuth registrados en el IdP. (Sólo disponible para…, Lista todos los usuarios registrados en el IdP. (Sólo disponible para…, Lista todos los dispositivos IoT registrados (Solo Administrador), AccessControlList (+34 more)

### Community 7 - "compilerOptions"
Cohesion: 0.08
Nodes (23): compilerOptions, allowImportingTsExtensions, baseUrl, isolatedModules, jsx, lib, module, moduleResolution (+15 more)

### Community 8 - "compilerOptions"
Cohesion: 0.09
Nodes (22): compilerOptions, allowImportingTsExtensions, erasableSyntaxOnly, lib, module, moduleDetection, moduleResolution, noEmit (+14 more)

### Community 9 - "physical_access_authenticate"
Cohesion: 0.18
Nodes (10): physical_access_authenticate(), Endpoint dedicado a dispositivos físicos M2M. Valida token, realiza control de…, get_user_by_id(), Busca los datos de un usuario por su ID en SQLite., BackgroundTasks, Verifica que buscar un usuario que no existe retorna None., Verifica que guardar un usuario con ID existente lo actualiza., Tests para el servicio de almacenamiento (SQLite + ChromaDB). (+2 more)

### Community 10 - "What You Must Do When Invoked"
Cohesion: 0.07
Nodes (26): For /graphify add and --watch, For /graphify query, For the commit hook and native CLAUDE.md integration, For --update and --cluster-only, /graphify, Honesty Rules, Interpreter guard for subcommands, Part A - Structural extraction for code files (+18 more)

### Community 11 - "security.py"
Cohesion: 0.13
Nodes (19): limiter.py — Instancia central de rate limiting usando slowapi. Separado en…, generate_api_key(), hash_api_key(), init_security(), security.py — Módulo de Seguridad para FaceSentinel Implementa JWT, API Keys, y…, Genera una API Key segura de 64 caracteres hex., Hashea una API Key con SHA-256 para almacenamiento seguro., Registra una nueva API Key para un dispositivo. Args: name: Nombre descriptivo… (+11 more)

### Community 12 - "face_recognition.py"
Cohesion: 0.27
Nodes (9): get_embedding(), face_recognition.py — Motor de Reconocimiento Facial FaceSentinel Usa DeepFace…, Usa DeepFace (ArcFace) para extraer el vector matemático del rostro., Procesa una foto nueva y guarda el usuario en SQLite y ChromaDB., Convierte la foto de la cámara (o usa el numpy array directamente) en vector y…, register_face(), verify_face(), Guarda al usuario en AMBAS bases de datos al mismo tiempo (SQLite + ChromaDB). (+1 more)

### Community 13 - "remove_face"
Cohesion: 0.13
Nodes (15): delete_user_account(), Elimina un usuario del sistema, borrando sus vectores de ChromaDB y su perfil…, Elimina un dispositivo IoT registrado (Solo Administrador), Elimina una regla de acceso ACL/RBAC por su ID (Solo Administrador), remove_device(), remove_device_acl(), Elimina toda huella biométrica y de registro de un usuario en el sistema, remove_face() (+7 more)

### Community 14 - "get_device_by_token"
Cohesion: 0.25
Nodes (6): get_device_by_token(), Busca en IoTDevice usando token_lookup_hash (SHA-256) O(1) y verifica con…, Tests para verificar los fixes de seguridad aplicados., Fix #2: DELETE /users/{id} sin autenticacion debe retornar 401., Fix #6: Dispositivo registrado almacena token_lookup_hash y se busca en O(1)., TestSecurityHardening

### Community 15 - "is_blockchain_available"
Cohesion: 0.18
Nodes (14): get_client_logs(), get_user_auth_history(), get, Consulta el historial de autenticaciones de un usuario en la blockchain (o…, Obtiene los registros de autenticación asociados a un clientId específico en la…, get, root(), get_auth_history() (+6 more)

### Community 16 - "log_authentication"
Cohesion: 0.14
Nodes (13): _compute_biometric_hash(), log_authentication(), Genera un hash SHA-256 del embedding facial. NUNCA se guarda el vector…, Registra un evento de autenticación en la blockchain. Args: user_id:…, test_blockchain.py — Tests para el servicio de blockchain Verifica la conexión,…, Tests para el hashing de datos biométricos., Verifica que el mismo embedding siempre produce el mismo hash., Verifica que embeddings diferentes producen hashes diferentes. (+5 more)

### Community 17 - "get_contract_info"
Cohesion: 0.17
Nodes (9): get_contract_info(), get_total_records(), Obtiene el número total de registros en el contrato., Retorna información general del contrato y la conexión., Tests para la inicialización y conexión blockchain., Verifica que is_blockchain_available retorna un booleano., Verifica que get_contract_info retorna información válida., Verifica que get_total_records retorna un entero. (+1 more)

### Community 18 - "comprehensive_liveness_check"
Cohesion: 0.16
Nodes (17): analyze_blink(), comprehensive_liveness_check(), estimate_head_pose(), _euclidean_distance(), _eye_aspect_ratio(), liveness.py — Motor Anti-Spoofing Avanzado para FaceSentinel Combina múltiples…, Estima la orientación de la cabeza usando landmarks faciales. Calcula los…, Ejecuta TODAS las verificaciones de liveness y retorna un score compuesto. Esta… (+9 more)

### Community 19 - "base64_to_image"
Cohesion: 0.24
Nodes (7): base64_to_image(), Convierte la imagen en texto (Base64) que envía el Frontend a un formato de…, Tests para la conversión Base64 -> OpenCV., Verifica que una imagen Base64 válida se convierte correctamente., Verifica que maneja correctamente el header data:image/jpeg;base64,..., Verifica que una imagen inválida lanza un error., TestImageConversion

### Community 20 - "deploy.py"
Cohesion: 0.22
Nodes (9): compile_contract(), deploy_contract(), deploy.py — Script de despliegue del Smart Contract AccessRegistry Compila el…, Guarda el ABI y la dirección del contrato en archivos JSON., Actualiza el archivo .env con la dirección del contrato desplegado., Compila el contrato Solidity y retorna el ABI y bytecode., Despliega el contrato en la blockchain y retorna la dirección., save_artifacts() (+1 more)

### Community 21 - "FaceSentinel 🛡️🔗"
Cohesion: 0.20
Nodes (9): 🏗️ Arquitectura del Sistema, 🛡️ Diagrama de Seguridad Anti-Spoofing, FaceSentinel 🛡️🔗, Paso 1: Levantar la Blockchain (Ganache), Paso 2: Preparar y Desplegar Backend, Paso 3: Levantar el Frontend, 🚀 Pasos para Ejecutar el Proyecto, 📋 Requisitos Previos (+1 more)

### Community 22 - "Ponytail"
Cohesion: 0.40
Nodes (4): Persistence, Ponytail, Rules, The ladder

### Community 23 - "websocket_liveness"
Cohesion: 0.14
Nodes (12): Endpoint interactivo que recibe frames de video en tiempo real, rastrea los…, websocket_liveness(), analyze_frequency(), analyze_texture(), Analiza la textura facial para distinguir piel real de pantallas/impresiones.…, Analiza el espectro de frecuencia de la imagen facial. Las pantallas y las…, Tests para el motor de anti-spoofing., Verifica que el análisis de textura retorna un resultado válido. (+4 more)

### Community 24 - "card.tsx"
Cohesion: 0.29
Nodes (6): Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle

### Community 25 - "test_recognition.py"
Cohesion: 0.28
Nodes (8): empty_image_base64(), fixture, test_recognition.py — Tests unitarios para el servicio de reconocimiento facial…, Genera una imagen de prueba en Base64 (cuadro negro con un círculo blanco)., Genera una imagen vacía (negra) sin ningún rostro., Genera un embedding facial simulado (vector de 512 dimensiones)., sample_embedding(), sample_image_base64()

### Community 26 - "React + TypeScript + Vite"
Cohesion: 0.50
Nodes (3): Expanding the ESLint configuration, React Compiler, React + TypeScript + Vite

### Community 28 - "clear_biometrics.py"
Cohesion: 0.47
Nodes (5): delete_user_biometric(), load_biometric_data(), main(), Carga los registros de ChromaDB y los cruza con la información de SQLite., Elimina la biometría de un usuario específico de ChromaDB y SQLite.

### Community 34 - "TestAuthentication"
Cohesion: 0.25
Nodes (5): Tests para los endpoints de autenticación., Verifica que el antiguo endpoint biométrico POST retorne 410 (Deprecated)., Verifica que falten campos retorne 422., Verifica que credenciales incorrectas retornen 401., TestAuthentication

### Community 35 - "logging_config.py"
Cohesion: 0.50
Nodes (3): logging_config.py — Configuración centralizada de logging para FaceSentinel…, Configura el sistema de logging profesional. Debe llamarse UNA VEZ al iniciar…, setup_logging()

### Community 36 - "crop_face"
Cohesion: 0.67
Nodes (3): crop_face(), main(), Recorta el rostro detectado de la imagen original aplicando un margen de…

### Community 37 - "button.tsx"
Cohesion: 0.67
Nodes (3): Button, ButtonProps, buttonVariants

### Community 38 - "tabs.tsx"
Cohesion: 0.50
Nodes (3): TabsContent, TabsList, TabsTrigger

### Community 39 - "reset_db.py"
Cohesion: 0.83
Nodes (3): main(), reset_chromadb(), reset_sqlite()

### Community 54 - "TestRegistration"
Cohesion: 0.25
Nodes (5): Tests para el endpoint de registro de usuarios., Verifica que registrar sin credenciales de admin da 401., Verifica que registrar sin imagen da error 422., Verifica que campos vacíos son procesados., TestRegistration

### Community 55 - "BlinkTracker"
Cohesion: 0.33
Nodes (3): BlinkTracker, Actualiza el estado con el nuevo EAR. Retorna True si se acaba de completar un…, Rastrea el historial de EAR (Eye Aspect Ratio) a través de múltiples frames…

### Community 56 - "TestBlockchain"
Cohesion: 0.33
Nodes (4): Tests para los endpoints de blockchain., Verifica que el endpoint de estado blockchain responde., Verifica consulta de historial cuando blockchain no está disponible., TestBlockchain

### Community 57 - "TestHealth"
Cohesion: 0.33
Nodes (4): Tests para verificar que el servidor está online., Verifica que la raíz responde correctamente., Verifica que la documentación Swagger está disponible., TestHealth

### Community 59 - "create_access_token"
Cohesion: 0.50
Nodes (5): create_access_token(), generate_idp_token(), Genera un JSON Web Token (JWT) con los datos proporcionados. Args: data:…, Genera un token JWT de federación (IdP) con una expiración muy corta. Incluye…, timedelta

### Community 60 - "get_current_user"
Cohesion: 0.40
Nodes (5): get_current_user(), Dependency de FastAPI que protege un endpoint. Acepta autenticación por JWT…, Verifica y decodifica un JWT. Args: token: El JWT a verificar Returns: Payload…, verify_token(), HTTPAuthorizationCredentials

## Knowledge Gaps
- **133 isolated node(s):** `name`, `private`, `version`, `type`, `dev` (+128 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **9 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `base64_to_image()` connect `base64_to_image` to `endpoints.py`, `image_processing.py`, `physical_access_authenticate`, `face_recognition.py`, `websocket_liveness`, `test_recognition.py`?**
  _High betweenness centrality (0.034) - this node is a cross-community bridge._
- **Why does `get_device_by_token()` connect `get_device_by_token` to `endpoints.py`, `physical_access_authenticate`, `test_api.py`, `storage.py`?**
  _High betweenness centrality (0.028) - this node is a cross-community bridge._
- **Why does `comprehensive_liveness_check()` connect `comprehensive_liveness_check` to `endpoints.py`, `physical_access_authenticate`, `test_recognition.py`, `websocket_liveness`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `physical_access_authenticate()` (e.g. with `M2MAuthRequest` and `log_authentication()`) actually correct?**
  _`physical_access_authenticate()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `name`, `private`, `version` to the rest of the system?**
  _133 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `endpoints.py` be split into smaller, more focused modules?**
  _Cohesion score 0.05093167701863354 - nodes in this community are weakly interconnected._
- **Should `image_processing.py` be split into smaller, more focused modules?**
  _Cohesion score 0.07899159663865546 - nodes in this community are weakly interconnected._