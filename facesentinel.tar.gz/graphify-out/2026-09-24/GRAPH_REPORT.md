# Graph Report - FaceSentinel - copia  (2026-09-23)

## Corpus Check
- 70 files · ~43,674 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 697 nodes · 986 edges · 76 communities (67 shown, 9 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 17 edges (avg confidence: 0.92)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `f413ca30`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- schemas.py
- image_processing.py
- devDependencies
- verify_client_secret
- dependencies
- App.tsx
- storage.py
- compilerOptions
- compilerOptions
- get_user_by_id
- What You Must Do When Invoked
- hash_api_key
- base64_to_image
- endpoints.py
- get_device_acl
- main.py
- _compute_biometric_hash
- get_total_records
- test_recognition.py
- TestImageConversion
- deploy.py
- FaceSentinel 🛡️🔗
- Ponytail
- test_metrics_collection.py
- card.tsx
- physical_access_authenticate
- React + TypeScript + Vite
- migrate_device_tokens.py
- clear_biometrics.py
- context7.md
- rules/graphify.md
- ponytail.md
- workflows/graphify.md
- register_oauth_client
- get
- edge_gateway.py
- button.tsx
- tabs.tsx
- TestAuthentication
- input.tsx
- label.tsx
- tsconfig.json
- hash_client_secret
- security.py
- TestRegistration
- get_user_auth_info_by_id
- blockchain.py
- Base
- get_current_user
- is_blockchain_available
- log_authentication
- test_api.py
- FaceSentinel — Resultados Experimentales del Capítulo IV
- save_acl_rule
- get_devices
- api.ts
- TestBlockchain
- TestHealth
- enroll_my_biometrics
- list_oauth_clients
- list_users
- reset_db.py
- save_access_log

## God Nodes (most connected - your core abstractions)
1. `compilerOptions` - 18 edges
2. `compilerOptions` - 18 edges
3. `base64_to_image()` - 15 edges
4. `physical_access_authenticate()` - 14 edges
5. `is_blockchain_available()` - 14 edges
6. `comprehensive_liveness_check()` - 12 edges
7. `What You Must Do When Invoked` - 12 edges
8. `websocket_liveness()` - 11 edges
9. `log_experiment_metric()` - 11 edges
10. `get_user_by_id()` - 11 edges

## Surprising Connections (you probably didn't know these)
- `admin_headers()` --calls--> `create_access_token()`  [EXTRACTED]
  tests/test_api.py → app/core/security.py
- `create_test_users()` --calls--> `hash_client_secret()`  [EXTRACTED]
  create_test_users.py → app/core/security.py
- `test_log_experiment_metric_live()` --calls--> `log_experiment_metric()`  [EXTRACTED]
  tests/test_metrics_collection.py → app/services/metrics_collector.py
- `register_oauth_client()` --uses--> `ClientCreate`  [INFERRED]
  app/api/endpoints.py → app/api/schemas.py
- `register_oauth_client()` --uses--> `ClientResponse`  [INFERRED]
  app/api/endpoints.py → app/api/schemas.py

## Import Cycles
- None detected.

## Communities (76 total, 9 thin omitted)

### Community 0 - "schemas.py"
Cohesion: 0.13
Nodes (22): ACLRuleCreate, AuthHistoryResponse, AuthRecordResponse, AuthRequest, AuthResponse, BlockchainInfoResponse, ClientCreate, ClientResponse (+14 more)

### Community 1 - "image_processing.py"
Cohesion: 0.08
Nodes (30): general_exception_handler(), Request, Captura errores de validación y retorna un 400 limpio., Captura errores inesperados y retorna un 500 con información útil., value_error_handler(), align_face(), assess_image_quality(), decode_base64_image() (+22 more)

### Community 2 - "devDependencies"
Cohesion: 0.06
Nodes (34): eslint, @eslint/js, eslint-plugin-react-hooks, eslint-plugin-react-refresh, devDependencies, eslint, @eslint/js, eslint-plugin-react-hooks (+26 more)

### Community 3 - "verify_client_secret"
Cohesion: 0.20
Nodes (8): Verifica si un client_secret en texto plano coincide con su hash bcrypt., verify_client_secret(), get_device_by_token(), Busca en IoTDevice usando token_lookup_hash (SHA-256) O(1) y verifica con…, Tests para verificar los fixes de seguridad aplicados., Fix #2: DELETE /users/{id} sin autenticacion debe retornar 401., Fix #6: Dispositivo registrado almacena token_lookup_hash y se busca en O(1)., TestSecurityHardening

### Community 4 - "dependencies"
Cohesion: 0.07
Nodes (29): axios, class-variance-authority, clsx, dependencies, axios, class-variance-authority, clsx, lucide-react (+21 more)

### Community 5 - "App.tsx"
Cohesion: 0.10
Nodes (17): App(), AccessControlView(), ACLRule, IoTDevice, UserRecord, AdminPanel(), AuditLog, Client (+9 more)

### Community 6 - "storage.py"
Cohesion: 0.17
Nodes (12): get_iot_device(), get_local_client_logs(), get_local_user_auth_history(), get_user_count(), IoTDevice, storage.py — Capa de almacenamiento dual (SQLite + ChromaDB) con SQLAlchemy 2.0…, Obtiene los registros de acceso locales para un cliente., Obtiene el historial de accesos de un usuario desde la DB local. (+4 more)

### Community 7 - "compilerOptions"
Cohesion: 0.08
Nodes (23): compilerOptions, allowImportingTsExtensions, baseUrl, isolatedModules, jsx, lib, module, moduleResolution (+15 more)

### Community 8 - "compilerOptions"
Cohesion: 0.09
Nodes (22): compilerOptions, allowImportingTsExtensions, erasableSyntaxOnly, lib, module, moduleDetection, moduleResolution, noEmit (+14 more)

### Community 9 - "get_user_by_id"
Cohesion: 0.21
Nodes (9): get_user_by_id(), Guarda al usuario en AMBAS bases de datos al mismo tiempo (SQLite + ChromaDB)., Busca los datos de un usuario por su ID en SQLite., save_user_data(), Verifica que buscar un usuario que no existe retorna None., Verifica que guardar un usuario con ID existente lo actualiza., Tests para el servicio de almacenamiento (SQLite + ChromaDB)., Verifica que se puede guardar y recuperar un usuario. (+1 more)

### Community 10 - "What You Must Do When Invoked"
Cohesion: 0.07
Nodes (26): For /graphify add and --watch, For /graphify query, For the commit hook and native CLAUDE.md integration, For --update and --cluster-only, /graphify, Honesty Rules, Interpreter guard for subcommands, Part A - Structural extraction for code files (+18 more)

### Community 11 - "hash_api_key"
Cohesion: 0.25
Nodes (8): generate_api_key(), hash_api_key(), Genera una API Key segura de 64 caracteres hex., Hashea una API Key con SHA-256 para almacenamiento seguro., Registra una nueva API Key para un dispositivo. Args: name: Nombre descriptivo…, Valida una API Key contra las keys registradas. Returns: Info del dispositivo…, register_api_key(), validate_api_key()

### Community 12 - "base64_to_image"
Cohesion: 0.20
Nodes (13): base64_to_image(), get_embedding(), face_recognition.py — Motor de Reconocimiento Facial FaceSentinel Usa DeepFace…, Convierte la foto de la cámara (o usa el numpy array directamente) en vector y…, Elimina toda huella biométrica y de registro de un usuario en el sistema, Convierte la imagen en texto (Base64) que envía el Frontend a un formato de…, Usa DeepFace (ArcFace) para extraer el vector matemático del rostro y mide el…, Procesa una foto nueva y guarda el usuario en SQLite y ChromaDB. (+5 more)

### Community 13 - "endpoints.py"
Cohesion: 0.19
Nodes (13): delete_user_account(), Elimina una regla de acceso ACL/RBAC por su ID (Solo Administrador), Elimina un usuario del sistema, borrando sus vectores de ChromaDB y su perfil…, Tarea en segundo plano que ejecuta el logging en Blockchain/SQLite y…, Elimina un dispositivo IoT registrado (Solo Administrador), _record_m2m_metrics_and_blockchain(), remove_device(), remove_device_acl() (+5 more)

### Community 14 - "get_device_acl"
Cohesion: 0.50
Nodes (4): get_device_acl(), Lista las reglas de acceso (ACL/RBAC) configuradas para un dispositivo (Solo…, get_device_acl_rules(), Retorna todas las reglas de acceso vigentes para un dispositivo específico.

### Community 15 - "main.py"
Cohesion: 0.19
Nodes (11): limiter.py — Instancia central de rate limiting usando slowapi. Separado en…, logging_config.py — Configuración centralizada de logging para FaceSentinel…, Configura el sistema de logging profesional. Debe llamarse UNA VEZ al iniciar…, setup_logging(), init_security(), Inicializa el módulo de seguridad. Crea una API Key por defecto para desarrollo…, lifespan(), Inicializa servicios cuando arranca el servidor. (+3 more)

### Community 16 - "_compute_biometric_hash"
Cohesion: 0.29
Nodes (6): _compute_biometric_hash(), Genera un hash SHA-256 del embedding facial. NUNCA se guarda el vector…, Tests para el hashing de datos biométricos., Verifica que el mismo embedding siempre produce el mismo hash., Verifica que embeddings diferentes producen hashes diferentes., TestBiometricHashing

### Community 17 - "get_total_records"
Cohesion: 0.25
Nodes (6): get_total_records(), Obtiene el número total de registros en el contrato., Tests para la inicialización y conexión blockchain., Verifica que is_blockchain_available retorna un booleano., Verifica que get_total_records retorna un entero., TestBlockchainConnection

### Community 18 - "test_recognition.py"
Cohesion: 0.06
Nodes (40): Endpoint interactivo que recibe frames de video en tiempo real, rastrea los…, websocket_liveness(), analyze_blink(), analyze_frequency(), analyze_texture(), BlinkTracker, comprehensive_liveness_check(), estimate_head_pose() (+32 more)

### Community 19 - "TestImageConversion"
Cohesion: 0.25
Nodes (5): Tests para la conversión Base64 -> OpenCV., Verifica que una imagen Base64 válida se convierte correctamente., Verifica que maneja correctamente el header data:image/jpeg;base64,..., Verifica que una imagen inválida lanza un error., TestImageConversion

### Community 20 - "deploy.py"
Cohesion: 0.22
Nodes (9): compile_contract(), deploy_contract(), deploy.py — Script de despliegue del Smart Contract AccessRegistry Compila el…, Guarda el ABI, el bytecode, métricas de gas y la dirección del contrato en…, Actualiza el archivo .env con la dirección del contrato desplegado., Compila el contrato Solidity y retorna el ABI y bytecode., Despliega el contrato en la blockchain y retorna la dirección., save_artifacts() (+1 more)

### Community 21 - "FaceSentinel 🛡️🔗"
Cohesion: 0.17
Nodes (11): 🏗️ Arquitectura del Sistema, 🛡️ Diagrama de Seguridad Anti-Spoofing, 🐳 Ejecución Universal con Docker Compose (Sin instalar nada extra), FaceSentinel 🛡️🔗, Paso 1: Levantar la Blockchain (Ganache), Paso 2: Preparar y Desplegar Backend, Paso 3: Levantar el Frontend, 🚀 Pasos para Ejecutar el Proyecto (Modo Manual) (+3 more)

### Community 22 - "Ponytail"
Cohesion: 0.40
Nodes (4): Persistence, Ponytail, Rules, The ladder

### Community 23 - "test_metrics_collection.py"
Cohesion: 0.12
Nodes (28): _append_to_backup_jsonl(), _ensure_data_dir(), flush_backup_to_csv(), _init_csv_if_missing(), log_experiment_metric(), Any, metrics_collector.py — Módulo de Telemetría y Recolección de Datos…, Punto de entrada principal para registrar un evento experimental. Garantiza que… (+20 more)

### Community 24 - "card.tsx"
Cohesion: 0.29
Nodes (6): Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle

### Community 25 - "physical_access_authenticate"
Cohesion: 0.20
Nodes (11): authenticate_by_password(), physical_access_authenticate(), Request, Verifica las credenciales tradicionales para roles Admin y Developer. Los…, Endpoint dedicado a dispositivos físicos M2M con telemetría para Tesis. Valida…, get_user_auth_info_by_username(), Obtiene los detalles de autenticación de un usuario por su username., Busca en AccessControlList si existe permiso para user_id O allowed_role en el… (+3 more)

### Community 26 - "React + TypeScript + Vite"
Cohesion: 0.50
Nodes (3): Expanding the ESLint configuration, React Compiler, React + TypeScript + Vite

### Community 28 - "clear_biometrics.py"
Cohesion: 0.47
Nodes (5): delete_user_biometric(), load_biometric_data(), main(), Carga los registros de ChromaDB y los cruza con la información de SQLite., Elimina la biometría de un usuario específico de ChromaDB y SQLite.

### Community 34 - "register_oauth_client"
Cohesion: 0.15
Nodes (13): add_device_acl(), authenticate_user(), Recibe los datos y la foto, y los envía a la IA para extraer el vector., [DEPRECADO] Endpoint vulnerable a API Bypass. La autenticación biométrica ahora…, Registra una nueva aplicación de terceros (cliente OAuth) y crea su cuenta…, Registra un nuevo dispositivo físico en SQLite. Genera y retorna un token de…, Asocia una nueva regla de acceso (ACL/RBAC) a un dispositivo (Solo…, register_device() (+5 more)

### Community 35 - "get"
Cohesion: 0.22
Nodes (8): blockchain_status(), get_user_auth_history(), get, Consulta el historial de autenticaciones de un usuario en la blockchain (o…, Retorna el estado actual de la conexión con la blockchain y la información del…, get_contract_info(), Retorna información general del contrato y la conexión., Verifica que get_contract_info retorna información válida.

### Community 36 - "edge_gateway.py"
Cohesion: 0.15
Nodes (14): BlinkStateMachine, compute_ear(), crop_face_from_mesh(), _euclidean(), get_avg_ear(), main(), Detecta un parpadeo humano completo (ojos abiertos → cerrados → abiertos).…, Actualiza la FSM con el EAR del frame actual y el frame BGR. Retorna True… (+6 more)

### Community 37 - "button.tsx"
Cohesion: 0.67
Nodes (3): Button, ButtonProps, buttonVariants

### Community 38 - "tabs.tsx"
Cohesion: 0.50
Nodes (3): TabsContent, TabsList, TabsTrigger

### Community 39 - "TestAuthentication"
Cohesion: 0.25
Nodes (5): Tests para los endpoints de autenticación., Verifica que el antiguo endpoint biométrico POST retorne 410 (Deprecated)., Verifica que falten campos retorne 422., Verifica que credenciales incorrectas retornen 401., TestAuthentication

### Community 54 - "hash_client_secret"
Cohesion: 0.25
Nodes (8): change_my_password(), Permite a un Administrador o Desarrollador logueado cambiar su contraseña., hash_client_secret(), Hashea un client_secret usando la librería bcrypt de forma directa., Actualiza la contraseña hasheada de un usuario en SQLite., update_user_password(), create_test_users(), put

### Community 55 - "security.py"
Cohesion: 0.28
Nodes (8): create_access_token(), generate_idp_token(), security.py — Módulo de Seguridad para FaceSentinel Implementa JWT, API Keys, y…, Dependency que solo permite acceso a administradores. Se encadena con…, Genera un JSON Web Token (JWT) con los datos proporcionados. Args: data:…, Genera un token JWT de federación (IdP) con una expiración muy corta. Incluye…, require_admin(), timedelta

### Community 56 - "TestRegistration"
Cohesion: 0.25
Nodes (5): Tests para el endpoint de registro de usuarios., Verifica que registrar sin credenciales de admin da 401., Verifica que registrar sin imagen da error 422., Verifica que campos vacíos son procesados., TestRegistration

### Community 57 - "get_user_auth_info_by_id"
Cohesion: 0.33
Nodes (6): get_my_client_app(), Retorna la configuración de la aplicación cliente asociada al Desarrollador…, get_oauth_client(), get_user_auth_info_by_id(), Busca y retorna un cliente OAuth por su ID. Deserializa las URIs de redirección…, Obtiene los detalles de autenticación de un usuario por su ID (Cédula).

### Community 58 - "blockchain.py"
Cohesion: 0.22
Nodes (5): Settings, _auto_deploy_contract(), blockchain.py — Servicio de integración con Smart Contract Proporciona…, Despliega automáticamente el contrato en Ganache si no existe., BaseSettings

### Community 59 - "Base"
Cohesion: 0.25
Nodes (9): Base, init_sqlite(), OAuthClient, Crea las tablas si no existen al arrancar el sistema y siembra el admin inicial…, Guarda un nuevo cliente de OAuth en la base de datos relacional y crea…, Clase base declarativa de SQLAlchemy 2.0, save_oauth_client(), User (+1 more)

### Community 60 - "get_current_user"
Cohesion: 0.40
Nodes (5): get_current_user(), Dependency de FastAPI que protege un endpoint. Acepta autenticación por JWT…, Verifica y decodifica un JWT. Args: token: El JWT a verificar Returns: Payload…, verify_token(), HTTPAuthorizationCredentials

### Community 62 - "is_blockchain_available"
Cohesion: 0.29
Nodes (8): get_client_logs(), Obtiene los registros de autenticación asociados a un clientId específico en la…, get, root(), get_recent_records_by_client(), is_blockchain_available(), Verifica si el servicio de blockchain está disponible., Consulta el historial de autenticaciones de un cliente en la blockchain. Args:…

### Community 63 - "log_authentication"
Cohesion: 0.20
Nodes (9): get_auth_history(), log_authentication(), Registra un evento de autenticación en la blockchain. Args: user_id:…, Consulta el historial de autenticaciones de un usuario en la blockchain. Args:…, test_blockchain.py — Tests para el servicio de blockchain Verifica la conexión,…, Tests para verificar que el sistema funciona sin blockchain., Verifica que log_authentication no falla si blockchain no está disponible., Verifica que get_auth_history no falla si blockchain no está disponible. (+1 more)

### Community 64 - "test_api.py"
Cohesion: 0.28
Nodes (8): admin_headers(), client(), fixture, test_api.py — Tests de integración para los endpoints de la API Usa FastAPI…, Crea un cliente de prueba de FastAPI., Genera una imagen de prueba en Base64., Crea token JWT con rol admin para pruebas autorizadas., sample_image_base64()

### Community 65 - "FaceSentinel — Resultados Experimentales del Capítulo IV"
Cohesion: 0.25
Nodes (7): 1. Matriz de Confusión y Métricas de Rendimiento Biométrico, 2. Análisis de Causa Raíz de Falsos Negativos (Condiciones Ambientales), 3. Desglose de Latencias de Procesamiento (Milisegundos), 4. Métricas de Discriminación Anti-Spoofing y Biometría, 5. Eficiencia y Rendimiento Blockchain (Smart Contract), FaceSentinel — Resultados Experimentales del Capítulo IV, Indicadores de Eficacia Biometría y Anti-Spoofing

### Community 66 - "save_acl_rule"
Cohesion: 0.50
Nodes (4): AccessControlList, Any, Registra una regla de acceso (ACL/RBAC) para un dispositivo IoT., save_acl_rule()

### Community 67 - "get_devices"
Cohesion: 0.50
Nodes (4): get_devices(), Lista todos los dispositivos IoT registrados (Solo Administrador), get_all_devices(), Retorna todos los dispositivos IoT registrados.

### Community 69 - "TestBlockchain"
Cohesion: 0.33
Nodes (4): Tests para los endpoints de blockchain., Verifica que el endpoint de estado blockchain responde., Verifica consulta de historial cuando blockchain no está disponible., TestBlockchain

### Community 70 - "TestHealth"
Cohesion: 0.33
Nodes (4): Tests para verificar que el servidor está online., Verifica que la raíz responde correctamente., Verifica que la documentación Swagger está disponible., TestHealth

### Community 71 - "enroll_my_biometrics"
Cohesion: 0.50
Nodes (4): enroll_my_biometrics(), Permite a un Desarrollador o Administrador registrar su rostro para iniciar…, BiometricsEnrollRequest, Modelo para enrolar la biometría facial del usuario logueado.

### Community 72 - "list_oauth_clients"
Cohesion: 0.50
Nodes (4): list_oauth_clients(), Lista todos los clientes OAuth registrados en el IdP. (Sólo disponible para…, get_all_oauth_clients(), Retorna todas las aplicaciones de terceros registradas en el sistema.

### Community 73 - "list_users"
Cohesion: 0.50
Nodes (4): list_users(), Lista todos los usuarios registrados en el IdP. (Sólo disponible para…, get_all_users(), Retorna todos los usuarios registrados.

### Community 74 - "reset_db.py"
Cohesion: 0.83
Nodes (3): main(), reset_chromadb(), reset_sqlite()

### Community 75 - "save_access_log"
Cohesion: 0.67
Nodes (3): AccessLog, Guarda un registro de acceso local (respaldo de la blockchain)., save_access_log()

## Knowledge Gaps
- **140 isolated node(s):** `name`, `private`, `version`, `type`, `dev` (+135 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **9 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `base64_to_image()` connect `base64_to_image` to `image_processing.py`, `endpoints.py`, `test_recognition.py`, `TestImageConversion`, `physical_access_authenticate`?**
  _High betweenness centrality (0.031) - this node is a cross-community bridge._
- **Why does `get_device_by_token()` connect `verify_client_secret` to `test_api.py`, `physical_access_authenticate`, `endpoints.py`, `storage.py`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **Why does `log_experiment_metric()` connect `test_metrics_collection.py` to `endpoints.py`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `physical_access_authenticate()` (e.g. with `_record_m2m_metrics_and_blockchain()` and `M2MAuthRequest`) actually correct?**
  _`physical_access_authenticate()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `name`, `private`, `version` to the rest of the system?**
  _140 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `schemas.py` be split into smaller, more focused modules?**
  _Cohesion score 0.13043478260869565 - nodes in this community are weakly interconnected._
- **Should `image_processing.py` be split into smaller, more focused modules?**
  _Cohesion score 0.07899159663865546 - nodes in this community are weakly interconnected._