# Graph Report - FaceSentinel - copia  (2026-09-27)

## Corpus Check
- 303 files · ~1,274,127 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 3880 nodes · 6644 edges · 297 communities (263 shown, 34 thin omitted)
- Extraction: 99% EXTRACTED · 1% INFERRED · 0% AMBIGUOUS · INFERRED: 81 edges (avg confidence: 0.87)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `bb6ac50f`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- endpoints.py
- image_processing.py
- devDependencies
- CameraWorker
- dependencies
- AdminPanel.tsx
- general_exception_handler
- compilerOptions
- compilerOptions
- face_recognition.py
- What You Must Do When Invoked
- calibrate_device.py
- compileWorkflowInternal
- delete_user_account
- storage.py
- main.py
- render-sequence.mjs
- geometry.mjs
- test_recognition.py
- startPreview
- deploy.py
- FaceSentinel 🛡️🔗
- Ponytail
- test_e2e_telemetry.py
- card.tsx
- render-dataflow.mjs
- React + TypeScript + Vite
- migrate_device_tokens.py
- workflow-compiler.mjs
- context7.md
- rules/graphify.md
- ponytail.md
- workflows/graphify.md
- render-architecture.mjs
- enroll_camera_face.py
- edge_gateway.py
- button.tsx
- tabs.tsx
- archify.mjs
- input.tsx
- label.tsx
- tsconfig.json
- required
- generated-validators.mjs
- properties
- physical_access_authenticate
- properties
- webm-artifact.smoke.mjs
- security.py
- properties
- check-update.mjs
- Authoring contract
- scenarios.mjs
- FaceSentinel — Resultados Experimentales y Evaluación Científica del Capítulo IV
- properties
- enum
- api.ts
- properties
- properties
- update-notifier.test.mjs
- visual-check.mjs
- reset_db.py
- cols
- TestAuthentication
- scripts
- clear_biometrics.py
- properties
- properties
- brand-marks.mjs
- check-render-output.mjs
- assertSafeDirectory
- architecture-delta.mjs
- update-contract.mjs
- layout-rules.test.mjs
- workflow-compiler.test.mjs
- $ref
- required
- buildDeltaSvg
- workflow-migration.test.mjs
- offline-font-browser.test.mjs
- cli.mjs
- properties
- finder-browser.test.mjs
- workflow.schema.json
- intent-trace-browser.test.mjs
- required
- properties
- cli.test.mjs
- golden.mjs
- desktop-readability.mjs
- output-path.mjs
- properties
- viewer-chrome-layout.test.mjs
- cli-output-types.test.mjs
- required
- required
- legend-contract.test.mjs
- engineering-profiles.mjs
- i18n.test.mjs
- properties
- properties
- $defs
- required
- inspectActiveClaim
- findChrome
- workflow-v2.mjs
- repository-evidence.test.mjs
- enum
- properties
- generate-brand-marks.mjs
- architecture-delta-markers.test.mjs
- real-repository-proof.test.mjs
- validateArchitectureDeltaHtml
- architecture-delta.test.mjs
- open-artifact.mjs
- dataflow.schema.json
- lifecycle.schema.json
- properties
- focus-browser.test.mjs
- guided-views-browser.test.mjs
- semantic-lens-browser.test.mjs
- semantic-radar.test.mjs
- workflow-compiler-hard-contract.test.mjs
- repository-evidence.mjs
- entries
- properties
- sequence.schema.json
- properties
- site-language-continuity.test.mjs
- preview.test.mjs
- architecture.schema.json
- legendEntry
- degraded.test.mjs
- reader-layout-browser.test.mjs
- readme-showcase.test.mjs
- release-package-gates.test.mjs
- Viewer Runtime reference
- properties
- enum
- collectArrows
- ordinary-model-floor.test.mjs
- output-path.test.mjs
- v1-compatibility.test.mjs
- frontend/package.json
- Delivery contract
- enum
- Archify JSON IR Schemas
- enum
- enum
- generate-validators.mjs
- architecture-compare-recovery.test.mjs
- authored-reachability.test.mjs
- chapter-delta-preview.test.mjs
- preview-contract.test.mjs
- relationship-permalink.test.mjs
- release-identity.test.mjs
- vertical-edge.test.mjs
- viewer-camera-browser.test.mjs
- wraps
- semanticRelation
- parseAttrs
- animation.test.mjs
- guided-views.test.mjs
- landing.test.mjs
- preset-tryon.test.mjs
- reach-share-card.test.mjs
- relationship-direct-explorer.test.mjs
- relationship-lens.test.mjs
- repair-receipt.test.mjs
- route-journey.test.mjs
- route-share-card.test.mjs
- semantic-legend-gateway.test.mjs
- sequence-column-fit.test.mjs
- share-card-export.test.mjs
- stable-update-manifest.test.mjs
- story-carrier.test.mjs
- story-director-strip.test.mjs
- story-follow-camera.test.mjs
- story-moment-link.test.mjs
- story-shelf.test.mjs
- Sequence Renderer
- enum
- enum
- enum
- artifact-receipt-flush.test.mjs
- chapter-handoff.test.mjs
- chapter-rail.test.mjs
- diagram-guide.test.mjs
- finder.test.mjs
- intent-trace.test.mjs
- .send
- motion-governor.test.mjs
- presentation.test.mjs
- relationship-pulse.test.mjs
- repository-evidence-replacement.test.mjs
- route-probe.test.mjs
- semantic-camera.test.mjs
- semantic-flow.test.mjs
- semantic-lens.test.mjs
- semantic-passport.test.mjs
- semantic-zoom.test.mjs
- settled-flow.test.mjs
- story-beat-navigator.test.mjs
- story-horizon.test.mjs
- TestRegistration
- Data Flow Renderer
- Lifecycle Renderer
- enum
- repository
- size
- viewBox
- point
- enum
- enum
- authoring-safety-contract.test.mjs
- automatic-port-spread.test.mjs
- clean-skill-staging.test.mjs
- render-output-checks.test.mjs
- skill-metadata.test.mjs
- story-trail.test.mjs
- Third-party notices
- validateSchema
- get_all_devices
- layout
- enum
- focus
- render-examples.mjs
- base-input-compatibility.test.mjs
- render-lifecycle.mjs
- enum
- TestBlockchain
- sources
- enum
- via
- width
- col
- via
- width
- sublabel
- col
- fromCol
- community-proof-intake.test.mjs
- cursor-onboarding.test.mjs
- delivery-contract.test.mjs
- generate-viewer.test.mjs
- guide-page.test.mjs
- proof-aperture.test.mjs
- Brand marks
- TestHealth
- bias
- pad
- row
- height
- label
- stage
- common.schema.json
- label
- labelSegment
- to
- y
- labelSegment
- repository-language-metadata.test.mjs
- toolbar-polish.test.mjs
- brand-marks/README.md
- archify-review/SKILL.md
- cornerRadius
- labelDy
- classification
- toSide
- fromSide
- checkout-line-endings.test.mjs
- ci-scope.test.mjs
- fail-migration-cleanup.mjs
- get_system_setting
- @radix-ui/react-label
- @radix-ui/react-slot
- @radix-ui/react-tabs
- react-router-dom
- tailwind-merge
- @vitejs/plugin-react
- col
- enum
- id
- @types/react-dom

## God Nodes (most connected - your core abstractions)
1. `compileWorkflowInternal()` - 175 edges
2. `asArray()` - 54 edges
3. `textUnits()` - 38 edges
4. `validateReadablePinnedGeometry()` - 31 edges
5. `isFinitePoint()` - 29 edges
6. `rectsOverlap()` - 28 edges
7. `validateWorkflow()` - 28 edges
8. `escapeHtml()` - 27 edges
9. `startPreview()` - 25 edges
10. `validateArchitecture()` - 23 edges

## Surprising Connections (you probably didn't know these)
- `admin_headers()` --calls--> `create_access_token()`  [EXTRACTED]
  tests/test_api.py → app/core/security.py
- `create_test_users()` --calls--> `hash_client_secret()`  [EXTRACTED]
  create_test_users.py → app/core/security.py
- `test_e2e_m2m_telemetry_flow()` --calls--> `hash_client_secret()`  [EXTRACTED]
  tests/test_e2e_telemetry.py → app/core/security.py
- `test_log_experiment_metric_live()` --calls--> `log_experiment_metric()`  [EXTRACTED]
  tests/test_metrics_collection.py → app/services/metrics_collector.py
- `test_e2e_m2m_telemetry_flow()` --calls--> `save_iot_device()`  [EXTRACTED]
  tests/test_e2e_telemetry.py → app/services/storage.py

## Import Cycles
- None detected.

## Communities (297 total, 34 thin omitted)

### Community 0 - "endpoints.py"
Cohesion: 0.06
Nodes (55): add_device_acl(), authenticate_user(), auto_calibrate_device(), get_single_device(), Registra un nuevo dispositivo físico en SQLite. Genera y retorna un token de…, Obtiene los detalles de configuración y calibración de un dispositivo., Actualiza la calibración LBP, URL de streaming RTSP, nombre o ubicación de un…, Calibra empíricamente una cámara en vivo conectándose a su stream_url. Captura… (+47 more)

### Community 1 - "image_processing.py"
Cohesion: 0.11
Nodes (22): align_face(), assess_image_quality(), decode_base64_image(), encode_image_to_base64(), normalize_illumination(), preprocess_face(), ndarray, image_processing.py — Utilidades de Preprocesamiento de Imagen para… (+14 more)

### Community 2 - "devDependencies"
Cohesion: 0.10
Nodes (21): eslint, @eslint/js, eslint-plugin-react-hooks, eslint-plugin-react-refresh, devDependencies, eslint, @eslint/js, eslint-plugin-react-hooks (+13 more)

### Community 3 - "CameraWorker"
Cohesion: 0.11
Nodes (16): CameraWorker, crop_face(), draw_glass_rect(), draw_hud_corners(), draw_pill_badge(), eye_aspect_ratio(), load_or_create_config(), main() (+8 more)

### Community 4 - "dependencies"
Cohesion: 0.11
Nodes (19): axios, class-variance-authority, clsx, dependencies, axios, class-variance-authority, clsx, lucide-react (+11 more)

### Community 5 - "AdminPanel.tsx"
Cohesion: 0.10
Nodes (18): App(), AccessControlView(), ACLRule, IoTDevice, UserRecord, AdminPanel(), AuditLog, Client (+10 more)

### Community 6 - "general_exception_handler"
Cohesion: 0.33
Nodes (7): general_exception_handler(), Request, Captura errores de validación y retorna un 400 limpio., Captura errores inesperados y retorna un 500 con información útil., value_error_handler(), Exception, exception_handler

### Community 7 - "compilerOptions"
Cohesion: 0.08
Nodes (23): compilerOptions, allowImportingTsExtensions, baseUrl, isolatedModules, jsx, lib, module, moduleResolution (+15 more)

### Community 8 - "compilerOptions"
Cohesion: 0.09
Nodes (22): compilerOptions, allowImportingTsExtensions, erasableSyntaxOnly, lib, module, moduleDetection, moduleResolution, noEmit (+14 more)

### Community 9 - "face_recognition.py"
Cohesion: 0.06
Nodes (37): admin_enroll_user_biometrics(), change_my_password(), enroll_my_biometrics(), get_my_client_app(), Actualiza la configuración o política de liveness de una aplicación cliente., Permite a un Administrador o Desarrollador logueado cambiar su contraseña., Permite a un Desarrollador o Administrador registrar su rostro para iniciar…, Permite al Administrador actualizar o enrolar nuevamente la biometría facial de… (+29 more)

### Community 10 - "What You Must Do When Invoked"
Cohesion: 0.07
Nodes (26): For /graphify add and --watch, For /graphify query, For the commit hook and native CLAUDE.md integration, For --update and --cluster-only, /graphify, Honesty Rules, Interpreter guard for subcommands, Part A - Structural extraction for code files (+18 more)

### Community 11 - "calibrate_device.py"
Cohesion: 0.31
Nodes (9): compute_lbp_features(), eye_aspect_ratio(), find_device_id_by_token(), load_camera_from_config(), main(), Busca la configuración de una cámara específica en cameras.json., Busca el device_id correspondiente al token o hash en SQLite., Actualiza el umbral en SQLite local y en el contenedor Docker si está activo. (+1 more)

### Community 12 - "compileWorkflowInternal"
Cohesion: 0.06
Nodes (96): throwDiagnosticError(), pointInBox(), pointRectDistance(), pointSegmentDistance(), rectsOverlap(), segmentIntersectsRect(), segmentRectClearance(), measureLegend() (+88 more)

### Community 13 - "delete_user_account"
Cohesion: 0.18
Nodes (11): delete_user_account(), Elimina un dispositivo IoT registrado (Solo Administrador), Elimina una regla de acceso ACL/RBAC por su ID (Solo Administrador), Elimina un usuario del sistema, borrando sus vectores de ChromaDB y su perfil…, remove_device(), remove_device_acl(), delete_acl_rule(), delete_iot_device() (+3 more)

### Community 14 - "storage.py"
Cohesion: 0.06
Nodes (41): get_device_acl(), list_oauth_clients(), list_users(), Lista todos los clientes OAuth registrados en el IdP. (Sólo disponible para…, Lista todos los usuarios registrados en el IdP. (Sólo disponible para…, Lista las reglas de acceso (ACL/RBAC) configuradas para un dispositivo (Solo…, AccessControlList, AccessLog (+33 more)

### Community 15 - "main.py"
Cohesion: 0.04
Nodes (56): blockchain_contract_info(), blockchain_status(), get_client_logs(), get_user_auth_history(), health_check(), get, Endpoint de salud del backend y estado de la red Blockchain., Retorna información en tiempo real del Smart Contract y de la red Ethereum… (+48 more)

### Community 16 - "render-sequence.mjs"
Cohesion: 0.10
Nodes (52): renderBoundaryFrame(), renderBoundaryLabel(), renderComponent(), renderConnectionLabel(), renderConnectionPath(), renderSvg(), renderFlowPath(), renderNode() (+44 more)

### Community 17 - "geometry.mjs"
Cohesion: 0.13
Nodes (55): validateArchitecture(), validateDataflow(), validateLifecycle(), validateSequence(), brandTopRailProblem(), recordDiagnostic(), asArray(), authoredAnalysisSegments() (+47 more)

### Community 18 - "test_recognition.py"
Cohesion: 0.04
Nodes (53): Endpoint interactivo que recibe frames de video en tiempo real, rastrea los…, websocket_liveness(), base64_to_image(), Convierte la foto de la cámara (o usa el numpy array directamente) en vector y…, Convierte la imagen en texto (Base64) a formato BGR para OpenCV, respetando la…, verify_face(), analyze_blink(), analyze_frequency() (+45 more)

### Community 19 - "startPreview"
Cohesion: 0.17
Nodes (26): cliPath, compactMessage(), diagramTypes, here, initialAuthoredOutput(), parseReceipt(), previewPage(), redactDiagnostic() (+18 more)

### Community 20 - "deploy.py"
Cohesion: 0.22
Nodes (9): compile_contract(), deploy_contract(), deploy.py — Script de despliegue del Smart Contract AccessRegistry Compila el…, Guarda el ABI, el bytecode, métricas de gas y la dirección del contrato en…, Actualiza el archivo .env con la dirección del contrato desplegado., Compila el contrato Solidity y retorna el ABI y bytecode., Despliega el contrato en la blockchain y retorna la dirección., save_artifacts() (+1 more)

### Community 21 - "FaceSentinel 🛡️🔗"
Cohesion: 0.17
Nodes (11): 🏗️ Arquitectura del Sistema, 🛡️ Diagrama de Seguridad Anti-Spoofing, 🐳 Ejecución Universal con Docker Compose (Sin instalar nada extra), FaceSentinel 🛡️🔗, Paso 1: Levantar la Blockchain (Ganache), Paso 2: Preparar y Desplegar Backend, Paso 3: Levantar el Frontend, 🚀 Pasos para Ejecutar el Proyecto (Modo Manual) (+3 more)

### Community 22 - "Ponytail"
Cohesion: 0.40
Nodes (4): Persistence, Ponytail, Rules, The ladder

### Community 23 - "test_e2e_telemetry.py"
Cohesion: 0.09
Nodes (35): _append_to_backup_jsonl(), _ensure_data_dir(), flush_backup_to_csv(), _init_csv_if_missing(), log_experiment_metric(), Any, metrics_collector.py — Módulo de Telemetría y Recolección de Datos…, Punto de entrada principal para registrar un evento experimental. Garantiza que… (+27 more)

### Community 24 - "card.tsx"
Cohesion: 0.29
Nodes (6): Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle

### Community 25 - "render-dataflow.mjs"
Cohesion: 0.10
Nodes (41): connectionSides(), automaticPorts, compositionFrames, __dirname, flowLabelSize(), flowSides(), layout, LEGEND_CATALOG (+33 more)

### Community 26 - "React + TypeScript + Vite"
Cohesion: 0.50
Nodes (3): Expanding the ESLint configuration, React Compiler, React + TypeScript + Vite

### Community 28 - "workflow-compiler.mjs"
Cohesion: 0.15
Nodes (21): withDiagnosticRecordingSuppressed(), authoredNodeHeight(), authoredNodeWidth(), canonicalReadableWorkflow(), cloneWorkflow(), compilerFailure(), readableMigrationProvidesCapacity(), compileWorkflowWithFeedback() (+13 more)

### Community 34 - "render-architecture.mjs"
Cohesion: 0.06
Nodes (54): DEFAULT_GRID, gridLayout(), resolveComponentPos(), validateGridPlacement(), alignFacingPorts(), architectureLegendEntries, automaticPorts, autoViewBoxFor() (+46 more)

### Community 35 - "enroll_camera_face.py"
Cohesion: 0.70
Nodes (4): crop_face_hd(), get_device_config(), main(), parse_args()

### Community 36 - "edge_gateway.py"
Cohesion: 0.15
Nodes (14): BlinkStateMachine, compute_ear(), crop_face_from_mesh(), _euclidean(), get_avg_ear(), main(), Detecta un parpadeo humano completo (ojos abiertos → cerrados → abiertos).…, Actualiza la FSM con el EAR del frame actual, el frame BGR y el recorte del… (+6 more)

### Community 37 - "button.tsx"
Cohesion: 0.67
Nodes (3): Button, ButtonProps, buttonVariants

### Community 38 - "tabs.tsx"
Cohesion: 0.50
Nodes (3): TabsContent, TabsList, TabsTrigger

### Community 39 - "archify.mjs"
Cohesion: 0.12
Nodes (50): assertEvidenceType(), CHECK_FIXES, checkerDiagnostics(), [command, ...args], commandBrands(), commandCheck(), commandCompare(), commandDeliver() (+42 more)

### Community 51 - "required"
Cohesion: 0.13
Nodes (19): items, type, items, items, type, additionalProperties, required, type (+11 more)

### Community 54 - "generated-validators.mjs"
Cohesion: 0.06
Nodes (46): architecture, dataflow, func3(), lifecycle, pattern17, pattern18, pattern20, pattern4 (+38 more)

### Community 55 - "properties"
Cohesion: 0.04
Nodes (47): enum, additionalProperties, properties, type, blueprint, classic, editorial, none (+39 more)

### Community 56 - "physical_access_authenticate"
Cohesion: 0.06
Nodes (31): authenticate_by_password(), _dispatch_background_log(), physical_access_authenticate(), Request, Tarea en segundo plano que ejecuta el logging en Blockchain/SQLite y…, Lanza la grabación de métricas y blockchain en hilo daemon para garantizar…, Endpoint dedicado a dispositivos físicos M2M con telemetría para Tesis. Valida…, Verifica las credenciales tradicionales para roles Admin y Developer. Los… (+23 more)

### Community 57 - "properties"
Cohesion: 0.05
Nodes (44): $ref, description, enum, additionalProperties, properties, type, title, additionalProperties (+36 more)

### Community 58 - "webm-artifact.smoke.mjs"
Cohesion: 0.09
Nodes (39): captureCopiedShareCard(), captureReachShareCard(), captureRouteShareCard(), captureRouteVisualMatrix(), captureShareCard(), chrome, chromeProcess, delay() (+31 more)

### Community 59 - "security.py"
Cohesion: 0.10
Nodes (24): create_access_token(), generate_api_key(), generate_idp_token(), get_current_user(), hash_api_key(), hash_client_secret(), security.py — Módulo de Seguridad para FaceSentinel Implementa JWT, API Keys, y…, Genera un token JWT de federación (IdP) o sesión de usuario. Incluye al usuario… (+16 more)

### Community 60 - "properties"
Cohesion: 0.05
Nodes (42): $ref, type, type, $ref, minimum, type, $ref, properties (+34 more)

### Community 62 - "check-update.mjs"
Cohesion: 0.10
Nodes (39): acknowledgeUpdate(), assertSafeRegularFile(), CacheOperationRaceError, CachePathChangedError, cancelOperation(), cancelResponseBody(), canonicalizeTrustedDirectoryPrefix(), checkForUpdate() (+31 more)

### Community 63 - "Authoring contract"
Cohesion: 0.05
Nodes (38): Architecture, Authoring contract, Dataflow, Engineering profile default, Executable geometry rules, Hand-placed fallback, Language consistency, Legend contract (+30 more)

### Community 64 - "scenarios.mjs"
Cohesion: 0.07
Nodes (20): detectGuideLanguage(), formatScenarioList(), listScenarioRecipes(), localized(), normalized(), publicGuideData(), RAW_RECIPES, recommendScenario() (+12 more)

### Community 65 - "FaceSentinel — Resultados Experimentales y Evaluación Científica del Capítulo IV"
Cohesion: 0.22
Nodes (8): 1. Matriz de Confusión Global de Control de Acceso, 2. Evaluación Específica de Detección de Ataques de Presentación (PAD / ISO/IEC 30107-3), 3. Evaluación del Reconocimiento Facial Biométrico (ISO/IEC 19795-1), 4. Análisis de Robustez ante Condiciones Ambientales (Iluminación), 5. Benchmarking de Latencias del Pipeline (Milisegundos), 6. Eficiencia de Auditoría Blockchain (Smart Contract en Ethereum), FaceSentinel — Resultados Experimentales y Evaluación Científica del Capítulo IV, Indicadores Globales de Seguridad

### Community 66 - "properties"
Cohesion: 0.05
Nodes (39): $ref, additionalProperties, properties, type, title, additionalProperties, properties, type (+31 more)

### Community 67 - "enum"
Cohesion: 0.50
Nodes (4): qualityProfile, showcase, standard, enum

### Community 69 - "properties"
Cohesion: 0.05
Nodes (39): $ref, additionalProperties, properties, type, title, additionalProperties, properties, type (+31 more)

### Community 70 - "properties"
Cohesion: 0.05
Nodes (39): $ref, type, type, $ref, minimum, type, properties, minLength (+31 more)

### Community 71 - "update-notifier.test.mjs"
Cohesion: 0.07
Nodes (25): assertUnsafeCacheStateIsIgnored(), baseTime, checkerPath, committedStateFiles(), compactStateSource(), contractPath, fixture(), get() (+17 more)

### Community 72 - "visual-check.mjs"
Cohesion: 0.10
Nodes (27): baseReceipt(), CAPTURE_VIEWPORTS, CHROME_NO_SANDBOX_ENV, ChromeVisualBrowser, chromeVisualBrowserArgs(), cleanupCaptureSidecars(), contactSheetHtml(), evaluate() (+19 more)

### Community 73 - "reset_db.py"
Cohesion: 0.83
Nodes (3): main(), reset_chromadb(), reset_sqlite()

### Community 74 - "cols"
Cohesion: 0.50
Nodes (4): maximum, minimum, type, cols

### Community 75 - "TestAuthentication"
Cohesion: 0.25
Nodes (5): Tests para los endpoints de autenticación., Verifica que el antiguo endpoint biométrico POST retorne 410 (Deprecated)., Verifica que falten campos retorne 422., Verifica que credenciales incorrectas retornen 401., TestAuthentication

### Community 76 - "scripts"
Cohesion: 0.05
Nodes (36): bin, archify, description, devDependencies, ajv, parse5, saxes, simple-icons (+28 more)

### Community 77 - "clear_biometrics.py"
Cohesion: 0.47
Nodes (5): delete_user_biometric(), load_biometric_data(), main(), Carga los registros de ChromaDB y los cruza con la información de SQLite., Elimina la biometría de un usuario específico de ChromaDB y SQLite.

### Community 78 - "properties"
Cohesion: 0.06
Nodes (34): $ref, $ref, $ref, $ref, properties, $ref, type, type (+26 more)

### Community 79 - "properties"
Cohesion: 0.06
Nodes (33): $ref, type, type, $ref, $ref, $ref, properties, $ref (+25 more)

### Community 80 - "brand-marks.mjs"
Cohesion: 0.08
Nodes (36): asUrl(), attribute(), beforeDeadline(), captureBrandReference(), captureRemoteBrand(), captureTimeoutMilliseconds(), checkedFetch(), COLLECTIONS (+28 more)

### Community 81 - "check-render-output.mjs"
Cohesion: 0.09
Nodes (21): checks, collectLegendCollisions(), collectNonFiniteAttrs(), collectRelationshipCrossings(), composition, crossProduct(), decodeNumericReferences(), ELEMENT_NUMERIC_ATTRS (+13 more)

### Community 82 - "assertSafeDirectory"
Cohesion: 0.20
Nodes (28): assertCacheTargetAbsent(), assertRenameableCacheEntry(), assertSafeCacheEntry(), assertSafeDirectory(), cacheMkdir(), cacheMkdirWithToken(), cacheRename(), cacheRm() (+20 more)

### Community 83 - "architecture-delta.mjs"
Cohesion: 0.16
Nodes (26): BOUNDARY_FIELDS, boundaryIndex(), boundaryKey(), canonical(), canonicalArchitecture(), canonicalArchitectureJson(), compareArchitecture(), compareEntities() (+18 more)

### Community 84 - "update-contract.mjs"
Cohesion: 0.16
Nodes (22): emptyState(), hasOnlyKeys(), isPlainObject(), normalizeState(), validateCachedCandidate(), validateClaimOwner(), compareNumericIdentifiers(), comparePrerelease() (+14 more)

### Community 85 - "layout-rules.test.mjs"
Cohesion: 0.09
Nodes (13): assertRelationshipsAvoidAllNodeBorders(), assertWorkflowEdgesAvoidAllNodeBorders(), axisOverlapLength(), CASES, __dirname, EXAMPLES, SHRINK_CASES, skillRoot (+5 more)

### Community 86 - "workflow-compiler.test.mjs"
Cohesion: 0.12
Nodes (16): asciiGroupLabelTextRect(), assertReadableAdjacentResult(), assertRectInsideViewBox(), attribute(), attributeOrUndefined(), cli, compileSuccessfully(), __dirname (+8 more)

### Community 87 - "$ref"
Cohesion: 0.09
Nodes (25): items, type, items, type, $ref, items, minItems, type (+17 more)

### Community 88 - "required"
Cohesion: 0.13
Nodes (21): items, type, items, type, additionalProperties, required, type, col (+13 more)

### Community 89 - "buildDeltaSvg"
Cohesion: 0.16
Nodes (22): addNodeMarker(), addState(), annotateArchitectureSideSvg(), boundaryChangeMap(), boundaryElements(), boundaryMarkupByKey(), boundaryMarkupParts(), boundarySymbolMarkup() (+14 more)

### Community 90 - "workflow-migration.test.mjs"
Cohesion: 0.13
Nodes (12): clone(), createHorizontalRankMapper(), createMappedWorkflowCandidate(), intrinsicWorkflow(), mapExplicitCoordinates(), mappedNumber(), planningWorkflow(), cli (+4 more)

### Community 91 - "offline-font-browser.test.mjs"
Cohesion: 0.13
Nodes (16): assertFontCss(), assertOfflineArtifact(), EXPECTED_FACES, FONT_LICENSE, inspectDocuments(), cssResources(), visit(), evaluate() (+8 more)

### Community 92 - "cli.mjs"
Cohesion: 0.08
Nodes (45): renderSvg(), renderSvg(), loadDiagram(), loadDiagramWithBrandMarks(), outputPathGuards, RELATIONSHIP_COLLECTIONS, SEMANTIC_COLLECTIONS, START_TYPES (+37 more)

### Community 93 - "properties"
Cohesion: 0.11
Nodes (18): $ref, $ref, properties, type, animation, locale, output, quality_profile (+10 more)

### Community 94 - "finder-browser.test.mjs"
Cohesion: 0.15
Nodes (18): key(), load(), opened(), run(), search(), skillRoot, snapshot(), createViewerClick() (+10 more)

### Community 95 - "workflow.schema.json"
Cohesion: 0.10
Nodes (19): additionalProperties, $defs, side, $id, bottom, diagram_type, lanes, left (+11 more)

### Community 96 - "intent-trace-browser.test.mjs"
Cohesion: 0.31
Nodes (10): afterTimer(), click(), key(), load(), media(), move(), point(), run() (+2 more)

### Community 97 - "required"
Cohesion: 0.14
Nodes (19): items, additionalProperties, required, type, from, id, label, to (+11 more)

### Community 98 - "properties"
Cohesion: 0.11
Nodes (19): $ref, $ref, type, $ref, properties, minLength, type, type (+11 more)

### Community 99 - "cli.test.mjs"
Cohesion: 0.13
Nodes (11): cli, __dirname, skillRoot, tmp, artifactRoots, __dirname, repoRoot, skillRoot (+3 more)

### Community 100 - "golden.mjs"
Cohesion: 0.12
Nodes (15): check(), __dirname, expectFailure(), GOLDEN, landingPage, landingVersions, lock, pkg (+7 more)

### Community 101 - "desktop-readability.mjs"
Cohesion: 0.18
Nodes (13): DESKTOP_READABILITY_VIEWPORT, DESKTOP_READER_DIAGRAM_WIDTH, DESKTOP_READER_HORIZONTAL_CHROME, DESKTOP_READER_MIN_WIDTH, MIN_PROJECTED_NODE_TEXT_PX, __dirname, reader, skill (+5 more)

### Community 102 - "output-path.mjs"
Cohesion: 0.23
Nodes (16): canonicalFuturePath(), canonicalize(), directoryIdentityKey(), directorySemanticsCache, futurePathsAlias(), hasFileIdentity(), nearestExistingDirectory(), OutputPathError (+8 more)

### Community 103 - "properties"
Cohesion: 0.11
Nodes (18): enum, $ref, properties, maxLength, type, dot, id, note (+10 more)

### Community 104 - "viewer-chrome-layout.test.mjs"
Cohesion: 0.15
Nodes (12): publicState(), CASES, __dirname, edgePaintHitsUnderDock(), evaluate(), finalGeometry(), load(), resize() (+4 more)

### Community 105 - "cli-output-types.test.mjs"
Cohesion: 0.22
Nodes (6): architecture, base, cli, head, root, workflow

### Community 106 - "required"
Cohesion: 0.15
Nodes (17): items, additionalProperties, required, type, from, id, label, to (+9 more)

### Community 107 - "required"
Cohesion: 0.15
Nodes (16): items, guidedViews, items, maxItems, type, additionalProperties, items, required (+8 more)

### Community 108 - "legend-contract.test.mjs"
Cohesion: 0.17
Nodes (15): attrValues(), AUTO_KINDS, canonicalSvg(), CATALOGS, cli, clone(), __dirname, FIXTURES (+7 more)

### Community 109 - "engineering-profiles.mjs"
Cohesion: 0.18
Nodes (11): DEPLOYMENT_BOUNDARY_KINDS, deploymentOwnershipDiagnostics(), membership(), PRIVATE_STATE_TYPES, subject(), validateEngineeringProfile(), cli, __dirname (+3 more)

### Community 110 - "i18n.test.mjs"
Cohesion: 0.15
Nodes (13): catalogKeys(), SUPPORTED_LOCALES, AUTHORED_TEXT_KEYS, authoredExample(), cli, __dirname, evaluate(), example() (+5 more)

### Community 111 - "properties"
Cohesion: 0.13
Nodes (15): minimum, type, minimum, type, minimum, type, minimum, type (+7 more)

### Community 112 - "properties"
Cohesion: 0.13
Nodes (15): enum, link_mode, provider, revision, url, enum, properties, pattern (+7 more)

### Community 113 - "$defs"
Cohesion: 0.13
Nodes (15): enum, oneOf, type, $defs, animation, brandMark, cards, id (+7 more)

### Community 114 - "required"
Cohesion: 0.16
Nodes (16): additionalProperties, required, type, col, from, id, label, lane (+8 more)

### Community 115 - "inspectActiveClaim"
Cohesion: 0.26
Nodes (15): acquireOperation(), assertBoundedRegularFile(), corruptClaimStatus(), guardedCacheEntryRead(), guardedCacheRead(), hasActivePendingOperation(), inspectActiveClaim(), listOperations() (+7 more)

### Community 116 - "findChrome"
Cohesion: 0.19
Nodes (12): executable(), findChrome(), findOnPath(), cases, evaluate(), exported(), load(), skillRoot (+4 more)

### Community 117 - "workflow-v2.mjs"
Cohesion: 0.30
Nodes (10): clone(), diagnostic(), expandableViewBox(), legacyLayoutProbe(), legacyRequirementProbe(), migrateWorkflowDocument(), requiredViewBoxFrom(), result() (+2 more)

### Community 118 - "repository-evidence.test.mjs"
Cohesion: 0.25
Nodes (5): cli, fixture(), git(), here, skillRoot

### Community 119 - "enum"
Cohesion: 0.14
Nodes (14): enum, componentType, variant, dashed, default, emphasis, external, security (+6 more)

### Community 120 - "properties"
Cohesion: 0.15
Nodes (13): $ref, const, maxItems, minItems, type, properties, cards, diagram_type (+5 more)

### Community 121 - "generate-brand-marks.mjs"
Cohesion: 0.18
Nodes (13): catalog, catalogPath, domains, fail(), generated, here, ids, lookupForms() (+5 more)

### Community 122 - "architecture-delta-markers.test.mjs"
Cohesion: 0.34
Nodes (12): assertPreserved(), assertResolved(), attr(), compare(), descendants(), edgePaths(), markerId(), markerMap() (+4 more)

### Community 123 - "real-repository-proof.test.mjs"
Cohesion: 0.14
Nodes (11): artifactPath, automaticMcoRoot(), cli, __dirname, experimentArtifactPath, experimentSourcePath, pinnedSource, repoRoot (+3 more)

### Community 124 - "validateArchitectureDeltaHtml"
Cohesion: 0.22
Nodes (13): architectureDeltaChangeRows(), codepointOrder(), expectedReviewTargetSignature(), primaryReviewTags(), renderArchitectureDeltaHtml(), reviewIdentity(), reviewPrimaryStates(), reviewTargetSignature() (+5 more)

### Community 125 - "architecture-delta.test.mjs"
Cohesion: 0.15
Nodes (9): ArchitectureDeltaError, baseFixture, checkedArtifact, checkedReceipt, cli, __dirname, headFixture, skillRoot (+1 more)

### Community 126 - "open-artifact.mjs"
Cohesion: 0.39
Nodes (5): launchTarget(), openArtifact(), OPENERS, openLoopbackUrl(), target

### Community 127 - "dataflow.schema.json"
Cohesion: 0.15
Nodes (12): additionalProperties, $id, diagram_type, meta, nodes, schema_version, required, $schema (+4 more)

### Community 128 - "lifecycle.schema.json"
Cohesion: 0.15
Nodes (12): additionalProperties, $id, diagram_type, lanes, meta, schema_version, required, $schema (+4 more)

### Community 129 - "properties"
Cohesion: 0.15
Nodes (13): $ref, const, minItems, type, minItems, type, properties, cards (+5 more)

### Community 130 - "focus-browser.test.mjs"
Cohesion: 0.31
Nodes (11): click(), focus(), key(), load(), move(), point(), run(), select() (+3 more)

### Community 131 - "guided-views-browser.test.mjs"
Cohesion: 0.28
Nodes (11): activate(), click(), hash(), key(), load(), move(), point(), run() (+3 more)

### Community 132 - "semantic-lens-browser.test.mjs"
Cohesion: 0.26
Nodes (11): desktopBrowser(), desktopPointerCheck(), click(), hash(), key(), load(), move(), point() (+3 more)

### Community 133 - "semantic-radar.test.mjs"
Cohesion: 0.21
Nodes (9): CASES, __dirname, dragMouse(), evaluate(), loadArtifact(), observe(), radarRects(), skillRoot (+1 more)

### Community 134 - "workflow-compiler-hard-contract.test.mjs"
Cohesion: 0.21
Nodes (5): crossingAtForwardCollinearViaWorkflow(), nestedOutsideRightCorridorWorkflow(), oneLaneAnchors(), oneLaneWorkflow(), workflow()

### Community 135 - "repository-evidence.mjs"
Cohesion: 0.41
Nodes (10): evidenceFailure(), gitValue(), hasRepositoryEvidence(), runGit(), sourceLineCount(), verifiedSourcePath(), verifyRepositoryEvidence(), parseRepositoryRemote() (+2 more)

### Community 136 - "entries"
Cohesion: 0.17
Nodes (12): additionalProperties, properties, type, additionalProperties, properties, type, enum, $ref (+4 more)

### Community 137 - "properties"
Cohesion: 0.17
Nodes (12): $ref, const, type, minItems, type, properties, cards, diagram_type (+4 more)

### Community 138 - "sequence.schema.json"
Cohesion: 0.17
Nodes (11): additionalProperties, $id, diagram_type, meta, schema_version, required, $schema, title (+3 more)

### Community 139 - "properties"
Cohesion: 0.17
Nodes (12): type, $ref, const, minItems, type, properties, activations, cards (+4 more)

### Community 140 - "site-language-continuity.test.mjs"
Cohesion: 0.18
Nodes (7): clickAndNavigate(), __dirname, evaluate(), loadRuntime(), navigationPath, repoRoot, runtimePath

### Community 141 - "preview.test.mjs"
Cohesion: 0.33
Nodes (4): here, skillRoot, stateAt(), waitForState()

### Community 142 - "architecture.schema.json"
Cohesion: 0.18
Nodes (10): additionalProperties, $id, diagram_type, meta, schema_version, required, $schema, title (+2 more)

### Community 143 - "legendEntry"
Cohesion: 0.18
Nodes (11): legendEntry, maxLength, minLength, type, additionalProperties, minProperties, properties, type (+3 more)

### Community 144 - "degraded.test.mjs"
Cohesion: 0.20
Nodes (8): ARRAY_FIELDS, assertFriendlyFailure(), __dirname, EXAMPLES, installedRoot, render(), skillRoot, tmp

### Community 145 - "reader-layout-browser.test.mjs"
Cohesion: 0.29
Nodes (8): cases, evaluate(), load(), media(), skillRoot, snapshot(), stable(), viewport()

### Community 146 - "readme-showcase.test.mjs"
Cohesion: 0.20
Nodes (7): assetPath, __dirname, inspectGif(), receiptPath, repoRoot, skillRoot, skipSubBlocks()

### Community 147 - "release-package-gates.test.mjs"
Cohesion: 0.18
Nodes (3): currentNodeMajor, __dirname, repoRoot

### Community 148 - "Viewer Runtime reference"
Cohesion: 0.20
Nodes (9): Canonical exports, Exploration, Guided views and story, Motion and presentation, Reach Share Card, Route Share Card, Share Card, Truth boundary (+1 more)

### Community 149 - "properties"
Cohesion: 0.13
Nodes (15): $ref, minItems, type, const, title, additionalProperties, required, type (+7 more)

### Community 150 - "enum"
Cohesion: 0.20
Nodes (10): external, type, enum, active, decision, failure, neutral, start (+2 more)

### Community 151 - "collectArrows"
Cohesion: 0.36
Nodes (9): collectArrows(), collectCompositionFrames(), isCommand(), isPoint(), lineSegments(), parseRoutePoints(), pathSegments(), pointsFromPath() (+1 more)

### Community 152 - "ordinary-model-floor.test.mjs"
Cohesion: 0.20
Nodes (5): benchmark, here, repoRoot, skillRoot, tmp

### Community 153 - "output-path.test.mjs"
Cohesion: 0.20
Nodes (6): baseFixture, cli, headFixture, here, skillRoot, workflowFixture

### Community 154 - "v1-compatibility.test.mjs"
Cohesion: 0.20
Nodes (4): __dirname, OFFICIAL_V1_EXAMPLES, skillRoot, tmp

### Community 155 - "frontend/package.json"
Cohesion: 0.20
Nodes (9): name, private, scripts, build, dev, lint, preview, type (+1 more)

### Community 156 - "Delivery contract"
Cohesion: 0.22
Nodes (8): Automated browser evidence, Delivery contract, Handoff receipt, Last-Good Live Preview, Optional opening, Perceptual delivery gate, Recovering a failed comparison, Validate and deliver

### Community 157 - "enum"
Cohesion: 0.22
Nodes (9): auto, bottom-channel, drop, straight, top-channel, route, enum, left-channel (+1 more)

### Community 158 - "Archify JSON IR Schemas"
Cohesion: 0.22
Nodes (8): Archify JSON IR Schemas, Error format, Files, Legend presentation contract, Runtime validation, schema_version policy, Shared definitions (common.schema.json), Visual quality and engineering truth

### Community 159 - "enum"
Cohesion: 0.22
Nodes (9): auto, bottom-channel, drop, straight, route, enum, outside-right, return-left (+1 more)

### Community 160 - "enum"
Cohesion: 0.22
Nodes (9): dashed, default, emphasis, security, variant, enum, $ref, exception (+1 more)

### Community 161 - "generate-validators.mjs"
Cohesion: 0.22
Nodes (8): ajv, diagramTypes, __dirname, output, root, schemaIds, schemasDir, validatorCode

### Community 162 - "architecture-compare-recovery.test.mjs"
Cohesion: 0.22
Nodes (5): base, cases, cli, head, skillRoot

### Community 163 - "authored-reachability.test.mjs"
Cohesion: 0.22
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 164 - "chapter-delta-preview.test.mjs"
Cohesion: 0.22
Nodes (5): CASES, __dirname, PROOF_CASES, skillRoot, tmp

### Community 165 - "preview-contract.test.mjs"
Cohesion: 0.22
Nodes (8): chinese, delivery, english, here, readme, repoRoot, skill, skillRoot

### Community 166 - "relationship-permalink.test.mjs"
Cohesion: 0.22
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 167 - "release-identity.test.mjs"
Cohesion: 0.33
Nodes (7): checker, here, repoRoot, stableUpdateManifest(), writeFile(), writeValidDevelopmentFixture(), writeValidStableFixture()

### Community 168 - "vertical-edge.test.mjs"
Cohesion: 0.22
Nodes (5): bin, __dirname, REPRO, skillRoot, tmp

### Community 169 - "viewer-camera-browser.test.mjs"
Cohesion: 0.33
Nodes (8): cases, load(), run(), screenshot(), skillRoot, snapshot(), stable(), viewport()

### Community 170 - "wraps"
Cohesion: 0.25
Nodes (8): $ref, via, wraps, items, type, items, minItems, type

### Community 171 - "semanticRelation"
Cohesion: 0.18
Nodes (11): semanticRelation, $ref, from, to, from, to, additionalProperties, properties (+3 more)

### Community 172 - "parseAttrs"
Cohesion: 0.27
Nodes (10): projectedNodeTextPx(), attrEntries(), collectDesktopReadability(), collectLegendBoxes(), collectRelationshipLabelMasks(), estimatedTextWidth(), numberAttr(), parseAttrs() (+2 more)

### Community 173 - "animation.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, NODE_COLLECTION, skillRoot, tmp

### Community 174 - "guided-views.test.mjs"
Cohesion: 0.25
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 175 - "landing.test.mjs"
Cohesion: 0.25
Nodes (7): __dirname, docsRoot, landing, manifest, proofs, repoRoot, skillRoot

### Community 176 - "preset-tryon.test.mjs"
Cohesion: 0.25
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 177 - "reach-share-card.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, repoRoot, skillRoot, tmp

### Community 178 - "relationship-direct-explorer.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 179 - "relationship-lens.test.mjs"
Cohesion: 0.25
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 180 - "repair-receipt.test.mjs"
Cohesion: 0.25
Nodes (4): cli, here, skillRoot, tmp

### Community 181 - "route-journey.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 182 - "route-share-card.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, repoRoot, skillRoot, tmp

### Community 183 - "semantic-legend-gateway.test.mjs"
Cohesion: 0.25
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 184 - "sequence-column-fit.test.mjs"
Cohesion: 0.32
Nodes (6): __dirname, labelledSequence(), render(), renderOutcome(), skillRoot, wideSequence()

### Community 185 - "share-card-export.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, here, repoRoot, skillRoot, tmp

### Community 186 - "stable-update-manifest.test.mjs"
Cohesion: 0.29
Nodes (5): annotatedTaggerTime(), checker, git(), here, repoRoot

### Community 187 - "story-carrier.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 188 - "story-director-strip.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 189 - "story-follow-camera.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 190 - "story-moment-link.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 191 - "story-shelf.test.mjs"
Cohesion: 0.25
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 192 - "Sequence Renderer"
Cohesion: 0.29
Nodes (6): Column fit, Design Rules, Input, Layout budget, Legend, Sequence Renderer

### Community 193 - "enum"
Cohesion: 0.29
Nodes (7): auto, bottom-channel, straight, top-channel, route, enum, vertical-channel

### Community 194 - "enum"
Cohesion: 0.29
Nodes (7): dashed, default, emphasis, return, security, variant, enum

### Community 195 - "enum"
Cohesion: 0.29
Nodes (7): return, role, enum, async, branch, error, main

### Community 196 - "artifact-receipt-flush.test.mjs"
Cohesion: 0.29
Nodes (4): checker, cli, skillRoot, tmp

### Community 197 - "chapter-handoff.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 198 - "chapter-rail.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 199 - "diagram-guide.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 200 - "finder.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 201 - "intent-trace.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 202 - ".send"
Cohesion: 0.19
Nodes (13): PipeCdp, click(), key(), load(), record(), run(), skillRoot, load() (+5 more)

### Community 203 - "motion-governor.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 204 - "presentation.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 205 - "relationship-pulse.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 206 - "repository-evidence-replacement.test.mjs"
Cohesion: 0.29
Nodes (4): cases, cli, fixture(), skillRoot

### Community 207 - "route-probe.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 208 - "semantic-camera.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 209 - "semantic-flow.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 210 - "semantic-lens.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 211 - "semantic-passport.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 212 - "semantic-zoom.test.mjs"
Cohesion: 0.29
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 213 - "settled-flow.test.mjs"
Cohesion: 0.29
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 214 - "story-beat-navigator.test.mjs"
Cohesion: 0.29
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 215 - "story-horizon.test.mjs"
Cohesion: 0.29
Nodes (5): CASES, __dirname, skillRoot, template, tmp

### Community 216 - "TestRegistration"
Cohesion: 0.25
Nodes (5): Tests para el endpoint de registro de usuarios., Verifica que registrar sin credenciales de admin da 401., Verifica que registrar sin imagen da error 422., Verifica que campos vacíos son procesados., TestRegistration

### Community 217 - "Data Flow Renderer"
Cohesion: 0.33
Nodes (5): Data Flow Renderer, Design Rules, Input, Layout budget, Legend

### Community 218 - "Lifecycle Renderer"
Cohesion: 0.33
Nodes (5): Design Rules, Input, Layout budget, Legend, Lifecycle Renderer

### Community 219 - "enum"
Cohesion: 0.33
Nodes (6): auto, straight, route, enum, orthogonal-h, orthogonal-v

### Community 220 - "repository"
Cohesion: 0.33
Nodes (6): repository, additionalProperties, required, type, revision, url

### Community 221 - "size"
Cohesion: 0.33
Nodes (6): size, items, maxItems, minItems, prefixItems, type

### Community 222 - "viewBox"
Cohesion: 0.33
Nodes (6): viewBox, items, maxItems, minItems, prefixItems, type

### Community 223 - "point"
Cohesion: 0.33
Nodes (6): point, items, maxItems, minItems, prefixItems, type

### Community 224 - "enum"
Cohesion: 0.33
Nodes (6): side, bottom, left, right, top, enum

### Community 225 - "enum"
Cohesion: 0.33
Nodes (6): visualPreset, blueprint, classic, editorial, signal-flow, enum

### Community 226 - "authoring-safety-contract.test.mjs"
Cohesion: 0.33
Nodes (5): authoringContract, __dirname, schemaReadme, skill, skillRoot

### Community 228 - "clean-skill-staging.test.mjs"
Cohesion: 0.47
Nodes (5): canonicalNotices, git(), repositoryFixture(), stagerPath, write()

### Community 229 - "render-output-checks.test.mjs"
Cohesion: 0.33
Nodes (4): checker, __dirname, skillRoot, tmp

### Community 230 - "skill-metadata.test.mjs"
Cohesion: 0.33
Nodes (5): authoringContract, frontmatter, here, skill, skillRoot

### Community 231 - "story-trail.test.mjs"
Cohesion: 0.33
Nodes (4): CASES, __dirname, skillRoot, tmp

### Community 232 - "Third-party notices"
Cohesion: 0.33
Nodes (5): JetBrains Mono, No additional rights granted, OpenAI mark, Simple Icons, Third-party notices

### Community 233 - "validateSchema"
Cohesion: 0.90
Nodes (4): annotatedPath(), annotatePath(), formatErrors(), validateSchema()

### Community 234 - "get_all_devices"
Cohesion: 0.33
Nodes (6): get_devices(), Lista todos los dispositivos IoT registrados (Solo Administrador), Endpoint de aprovisionamiento Zero-Config para dispositivos de borde (Edge…, sync_devices_for_gateway(), get_all_devices(), Retorna todos los dispositivos IoT registrados.

### Community 235 - "layout"
Cohesion: 0.40
Nodes (5): additionalProperties, required, type, layout, mode

### Community 236 - "enum"
Cohesion: 0.40
Nodes (5): legendMode, auto, enum, all, hidden

### Community 237 - "focus"
Cohesion: 0.40
Nodes (5): items, minItems, type, $ref, focus

### Community 238 - "render-examples.mjs"
Cohesion: 0.40
Nodes (4): __dirname, outputRoot, skillRoot, TARGETS

### Community 239 - "base-input-compatibility.test.mjs"
Cohesion: 0.40
Nodes (3): here, skillRoot, tmp

### Community 240 - "render-lifecycle.mjs"
Cohesion: 0.10
Nodes (29): renderLegend(), automaticPorts, bandFor(), bandTitles(), __dirname, laneLabels, layout, LEGEND_CATALOG (+21 more)

### Community 241 - "enum"
Cohesion: 0.50
Nodes (4): enum, kind, region, security-group

### Community 242 - "TestBlockchain"
Cohesion: 0.33
Nodes (4): Tests para los endpoints de blockchain., Verifica que el endpoint de estado blockchain responde., Verifica consulta de historial cuando blockchain no está disponible., TestBlockchain

### Community 243 - "sources"
Cohesion: 0.50
Nodes (4): sources, maxItems, minItems, type

### Community 244 - "enum"
Cohesion: 0.50
Nodes (4): locale, enum, en, zh-CN

### Community 245 - "via"
Cohesion: 0.50
Nodes (4): $ref, via, items, type

### Community 246 - "width"
Cohesion: 0.50
Nodes (4): width, minimum, $ref, type

### Community 247 - "col"
Cohesion: 0.50
Nodes (4): maximum, minimum, type, col

### Community 248 - "via"
Cohesion: 0.50
Nodes (4): $ref, via, items, type

### Community 249 - "width"
Cohesion: 0.50
Nodes (4): width, minimum, $ref, type

### Community 251 - "col"
Cohesion: 0.50
Nodes (4): maximum, minimum, type, col

### Community 252 - "fromCol"
Cohesion: 0.50
Nodes (4): maximum, minimum, type, fromCol

### Community 254 - "cursor-onboarding.test.mjs"
Cohesion: 0.50
Nodes (3): __dirname, repoRoot, skillRoot

### Community 255 - "delivery-contract.test.mjs"
Cohesion: 0.50
Nodes (3): delivery, here, skill

### Community 257 - "guide-page.test.mjs"
Cohesion: 0.50
Nodes (3): __dirname, repoRoot, skillRoot

### Community 260 - "TestHealth"
Cohesion: 0.33
Nodes (4): Tests para verificar que el servidor está online., Verifica que la raíz responde correctamente., Verifica que la documentación Swagger está disponible., TestHealth

### Community 261 - "bias"
Cohesion: 0.50
Nodes (4): maximum, minimum, type, bias

### Community 262 - "pad"
Cohesion: 0.67
Nodes (3): minimum, type, pad

### Community 263 - "row"
Cohesion: 0.67
Nodes (3): row, minimum, type

### Community 264 - "height"
Cohesion: 0.67
Nodes (3): minimum, type, height

### Community 265 - "label"
Cohesion: 0.67
Nodes (3): minLength, type, label

### Community 266 - "stage"
Cohesion: 0.67
Nodes (3): stage, minimum, type

### Community 267 - "common.schema.json"
Cohesion: 0.50
Nodes (3): $id, $schema, title

### Community 268 - "label"
Cohesion: 0.67
Nodes (3): minLength, type, label

### Community 269 - "labelSegment"
Cohesion: 0.67
Nodes (3): minimum, type, labelSegment

### Community 270 - "to"
Cohesion: 0.67
Nodes (3): to, $ref, type

### Community 271 - "y"
Cohesion: 0.67
Nodes (3): y, minimum, type

### Community 272 - "labelSegment"
Cohesion: 0.67
Nodes (3): minimum, type, labelSegment

### Community 278 - "cornerRadius"
Cohesion: 0.67
Nodes (3): minimum, type, cornerRadius

### Community 286 - "get_system_setting"
Cohesion: 0.50
Nodes (4): get_system_security_policy(), Retorna la política de liveness activa para el portal central de FaceSentinel y…, get_system_setting(), Obtiene el valor de una configuración global del sistema.

### Community 293 - "col"
Cohesion: 0.67
Nodes (3): minimum, type, col

### Community 294 - "enum"
Cohesion: 0.67
Nodes (3): enum, engineering_profile, deployment-ownership

## Knowledge Gaps
- **1418 isolated node(s):** `__dirname`, `skillRoot`, `TYPES`, `COMPOSITION_CHECKS`, `CHECK_FIXES` (+1413 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **34 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `parseRepositoryRemote()` connect `repository-evidence.mjs` to `architecture-delta.mjs`?**
  _High betweenness centrality (0.010) - this node is a cross-community bridge._
- **Why does `compileWorkflowInternal()` connect `compileWorkflowInternal` to `render-architecture.mjs`, `validateSchema`, `cli.mjs`, `render-sequence.mjs`, `geometry.mjs`, `render-lifecycle.mjs`, `render-dataflow.mjs`, `workflow-migration.test.mjs`, `workflow-compiler.mjs`?**
  _High betweenness centrality (0.008) - this node is a cross-community bridge._
- **Why does `verifyRepositoryEvidence()` connect `repository-evidence.mjs` to `real-repository-proof.test.mjs`, `cli.mjs`?**
  _High betweenness centrality (0.008) - this node is a cross-community bridge._
- **What connects `__dirname`, `skillRoot`, `TYPES` to the rest of the system?**
  _1418 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `endpoints.py` be split into smaller, more focused modules?**
  _Cohesion score 0.062310949788263764 - nodes in this community are weakly interconnected._
- **Should `image_processing.py` be split into smaller, more focused modules?**
  _Cohesion score 0.10826210826210826 - nodes in this community are weakly interconnected._
- **Should `devDependencies` be split into smaller, more focused modules?**
  _Cohesion score 0.09523809523809523 - nodes in this community are weakly interconnected._