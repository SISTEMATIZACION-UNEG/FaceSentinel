# Graph Report - FaceSentinel - copia  (2026-09-23)

## Corpus Check
- 66 files · ~38,749 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 655 nodes · 915 edges · 69 communities (60 shown, 9 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 17 edges (avg confidence: 0.92)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `f413ca30`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- endpoints.py
- image_processing.py
- devDependencies
- physical_access_authenticate
- dependencies
- App.tsx
- storage.py
- compilerOptions
- compilerOptions
- get_user_by_id
- What You Must Do When Invoked
- security.py
- face_recognition.py
- delete_user_account
- get
- main.py
- _compute_biometric_hash
- get_total_records
- comprehensive_liveness_check
- base64_to_image
- deploy.py
- FaceSentinel 🛡️🔗
- Ponytail
- TestLiveness
- card.tsx
- test_recognition.py
- React + TypeScript + Vite
- migrate_device_tokens.py
- clear_biometrics.py
- context7.md
- rules/graphify.md
- ponytail.md
- workflows/graphify.md
- register_face
- logging_config.py
- edge_gateway.py
- button.tsx
- tabs.tsx
- TestAuthentication
- input.tsx
- label.tsx
- tsconfig.json
- analyze_frequency
- BlinkTracker
- TestRegistration
- change_my_password
- config.py
- general_exception_handler
- get_current_user
- get_client_logs
- is_blockchain_available
- analyze_blink
- websocket_liveness
- save_acl_rule
- get_devices
- api.ts

## God Nodes (most connected - your core abstractions)
1. `compilerOptions` - 18 edges
2. `compilerOptions` - 18 edges
3. `base64_to_image()` - 15 edges
4. `physical_access_authenticate()` - 14 edges
5. `is_blockchain_available()` - 14 edges
6. `comprehensive_liveness_check()` - 12 edges
7. `What You Must Do When Invoked` - 12 edges
8. `websocket_liveness()` - 11 edges
9. `get_user_by_id()` - 11 edges
10. `/graphify` - 11 edges

## Surprising Connections (you probably didn't know these)
- `create_test_users()` --calls--> `hash_client_secret()`  [EXTRACTED]
  create_test_users.py → app/core/security.py
- `register_oauth_client()` --uses--> `ClientCreate`  [INFERRED]
  app/api/endpoints.py → app/api/schemas.py
- `register_oauth_client()` --uses--> `ClientResponse`  [INFERRED]
  app/api/endpoints.py → app/api/schemas.py
- `authenticate_by_password()` --uses--> `PasswordAuthRequest`  [INFERRED]
  app/api/endpoints.py → app/api/schemas.py
- `change_my_password()` --uses--> `PasswordChangeRequest`  [INFERRED]
  app/api/endpoints.py → app/api/schemas.py

## Import Cycles
- None detected.

## Communities (69 total, 9 thin omitted)

### Community 0 - "endpoints.py"
Cohesion: 0.14
Nodes (26): ACLRuleCreate, AuthHistoryResponse, AuthRecordResponse, AuthRequest, AuthResponse, BiometricsEnrollRequest, BlockchainInfoResponse, ClientCreate (+18 more)

### Community 1 - "image_processing.py"
Cohesion: 0.10
Nodes (23): align_face(), assess_image_quality(), decode_base64_image(), encode_image_to_base64(), normalize_illumination(), preprocess_face(), image_processing.py — Utilidades de Preprocesamiento de Imagen para…, Normaliza la iluminación usando CLAHE (Contrast Limited Adaptive Histogram… (+15 more)

### Community 2 - "devDependencies"
Cohesion: 0.06
Nodes (34): eslint, @eslint/js, eslint-plugin-react-hooks, eslint-plugin-react-refresh, devDependencies, eslint, @eslint/js, eslint-plugin-react-hooks (+26 more)

### Community 3 - "physical_access_authenticate"
Cohesion: 0.05
Nodes (40): authenticate_by_password(), physical_access_authenticate(), Request, Verifica las credenciales tradicionales para roles Admin y Developer. Los…, Endpoint dedicado a dispositivos físicos M2M. Valida token, realiza control de…, create_access_token(), generate_idp_token(), Verifica si un client_secret en texto plano coincide con su hash bcrypt. (+32 more)

### Community 4 - "dependencies"
Cohesion: 0.07
Nodes (29): axios, class-variance-authority, clsx, dependencies, axios, class-variance-authority, clsx, lucide-react (+21 more)

### Community 5 - "App.tsx"
Cohesion: 0.10
Nodes (17): App(), AccessControlView(), ACLRule, IoTDevice, UserRecord, AdminPanel(), AuditLog, Client (+9 more)

### Community 6 - "storage.py"
Cohesion: 0.14
Nodes (20): AccessLog, Base, get_iot_device(), get_user_count(), init_sqlite(), IoTDevice, OAuthClient, storage.py — Capa de almacenamiento dual (SQLite + ChromaDB) con SQLAlchemy 2.0… (+12 more)

### Community 7 - "compilerOptions"
Cohesion: 0.08
Nodes (23): compilerOptions, allowImportingTsExtensions, baseUrl, isolatedModules, jsx, lib, module, moduleResolution (+15 more)

### Community 8 - "compilerOptions"
Cohesion: 0.09
Nodes (22): compilerOptions, allowImportingTsExtensions, erasableSyntaxOnly, lib, module, moduleDetection, moduleResolution, noEmit (+14 more)

### Community 9 - "get_user_by_id"
Cohesion: 0.21
Nodes (9): get_user_by_id(), Guarda al usuario en AMBAS bases de datos al mismo tiempo (SQLite + ChromaDB)., Busca los datos de un usuario por su ID en SQLite., save_user_data(), Verifica que buscar un usuario que no existe retorna None., Verifica que guardar un usuario con ID existente lo actualiza., Tests para el servicio de almacenamiento (SQLite + ChromaDB)., Verifica que se puede guardar y recuperar un usuario. (+1 more)

### Community 10 - "What You Must Do When Invoked"
Cohesion: 0.07
Nodes (26): For /graphify add and --watch, For /graphify query, For the commit hook and native CLAUDE.md integration, For --update and --cluster-only, /graphify, Honesty Rules, Interpreter guard for subcommands, Part A - Structural extraction for code files (+18 more)

### Community 11 - "security.py"
Cohesion: 0.17
Nodes (14): generate_api_key(), hash_api_key(), hash_client_secret(), security.py — Módulo de Seguridad para FaceSentinel Implementa JWT, API Keys, y…, Hashea un client_secret usando la librería bcrypt de forma directa., Genera una API Key segura de 64 caracteres hex., Hashea una API Key con SHA-256 para almacenamiento seguro., Registra una nueva API Key para un dispositivo. Args: name: Nombre descriptivo… (+6 more)

### Community 12 - "face_recognition.py"
Cohesion: 0.24
Nodes (9): get_embedding(), face_recognition.py — Motor de Reconocimiento Facial FaceSentinel Usa DeepFace…, Elimina toda huella biométrica y de registro de un usuario en el sistema, Usa DeepFace (ArcFace) para extraer el vector matemático del rostro., Convierte la foto de la cámara (o usa el numpy array directamente) en vector y…, remove_face(), verify_face(), delete_user() (+1 more)

### Community 13 - "delete_user_account"
Cohesion: 0.18
Nodes (11): delete_user_account(), Elimina un usuario del sistema, borrando sus vectores de ChromaDB y su perfil…, Elimina un dispositivo IoT registrado (Solo Administrador), Elimina una regla de acceso ACL/RBAC por su ID (Solo Administrador), remove_device(), remove_device_acl(), delete_acl_rule(), delete_iot_device() (+3 more)

### Community 14 - "get"
Cohesion: 0.13
Nodes (15): blockchain_status(), get_device_acl(), list_oauth_clients(), list_users(), get, Lista todos los clientes OAuth registrados en el IdP. (Sólo disponible para…, Lista todos los usuarios registrados en el IdP. (Sólo disponible para…, Retorna el estado actual de la conexión con la blockchain y la información del… (+7 more)

### Community 15 - "main.py"
Cohesion: 0.17
Nodes (13): limiter.py — Instancia central de rate limiting usando slowapi. Separado en…, init_security(), Inicializa el módulo de seguridad. Crea una API Key por defecto para desarrollo…, lifespan(), get, Inicializa servicios cuando arranca el servidor., root(), _auto_deploy_contract() (+5 more)

### Community 16 - "_compute_biometric_hash"
Cohesion: 0.29
Nodes (6): _compute_biometric_hash(), Genera un hash SHA-256 del embedding facial. NUNCA se guarda el vector…, Tests para el hashing de datos biométricos., Verifica que el mismo embedding siempre produce el mismo hash., Verifica que embeddings diferentes producen hashes diferentes., TestBiometricHashing

### Community 17 - "get_total_records"
Cohesion: 0.20
Nodes (7): get_total_records(), Obtiene el número total de registros en el contrato., Tests para la inicialización y conexión blockchain., Verifica que is_blockchain_available retorna un booleano., Verifica que get_contract_info retorna información válida., Verifica que get_total_records retorna un entero., TestBlockchainConnection

### Community 18 - "comprehensive_liveness_check"
Cohesion: 0.23
Nodes (11): comprehensive_liveness_check(), estimate_head_pose(), liveness.py — Motor Anti-Spoofing Avanzado para FaceSentinel Combina múltiples…, Estima la orientación de la cabeza usando landmarks faciales. Calcula los…, Ejecuta TODAS las verificaciones de liveness y retorna un score compuesto. Esta…, draw_status_bar(), frame_to_base64(), main() (+3 more)

### Community 19 - "base64_to_image"
Cohesion: 0.24
Nodes (7): base64_to_image(), Convierte la imagen en texto (Base64) que envía el Frontend a un formato de…, Tests para la conversión Base64 -> OpenCV., Verifica que una imagen Base64 válida se convierte correctamente., Verifica que maneja correctamente el header data:image/jpeg;base64,..., Verifica que una imagen inválida lanza un error., TestImageConversion

### Community 20 - "deploy.py"
Cohesion: 0.22
Nodes (9): compile_contract(), deploy_contract(), deploy.py — Script de despliegue del Smart Contract AccessRegistry Compila el…, Guarda el ABI, el bytecode y la dirección del contrato en archivos JSON., Actualiza el archivo .env con la dirección del contrato desplegado., Compila el contrato Solidity y retorna el ABI y bytecode., Despliega el contrato en la blockchain y retorna la dirección., save_artifacts() (+1 more)

### Community 21 - "FaceSentinel 🛡️🔗"
Cohesion: 0.17
Nodes (11): 🏗️ Arquitectura del Sistema, 🛡️ Diagrama de Seguridad Anti-Spoofing, 🐳 Ejecución Universal con Docker Compose (Sin instalar nada extra), FaceSentinel 🛡️🔗, Paso 1: Levantar la Blockchain (Ganache), Paso 2: Preparar y Desplegar Backend, Paso 3: Levantar el Frontend, 🚀 Pasos para Ejecutar el Proyecto (Modo Manual) (+3 more)

### Community 22 - "Ponytail"
Cohesion: 0.40
Nodes (4): Persistence, Ponytail, Rules, The ladder

### Community 23 - "TestLiveness"
Cohesion: 0.33
Nodes (4): Tests para el motor de anti-spoofing., Verifica que el análisis de textura retorna un resultado válido., Verifica que una imagen sin rostro falla el liveness., TestLiveness

### Community 24 - "card.tsx"
Cohesion: 0.29
Nodes (6): Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle

### Community 25 - "test_recognition.py"
Cohesion: 0.28
Nodes (8): empty_image_base64(), fixture, test_recognition.py — Tests unitarios para el servicio de reconocimiento facial…, Genera una imagen de prueba en Base64 (cuadro negro con un círculo blanco)., Genera una imagen vacía (negra) sin ningún rostro., Genera un embedding facial simulado (vector de 512 dimensiones)., sample_embedding(), sample_image_base64()

### Community 26 - "React + TypeScript + Vite"
Cohesion: 0.50
Nodes (3): Expanding the ESLint configuration, React Compiler, React + TypeScript + Vite

### Community 28 - "clear_biometrics.py"
Cohesion: 0.47
Nodes (5): delete_user_biometric(), load_biometric_data(), main(), Carga los registros de ChromaDB y los cruza con la información de SQLite., Elimina la biometría de un usuario específico de ChromaDB y SQLite.

### Community 34 - "register_face"
Cohesion: 0.15
Nodes (13): add_device_acl(), authenticate_user(), Recibe los datos y la foto, y los envía a la IA para extraer el vector., [DEPRECADO] Endpoint vulnerable a API Bypass. La autenticación biométrica ahora…, Registra una nueva aplicación de terceros (cliente OAuth) y crea su cuenta…, Registra un nuevo dispositivo físico en SQLite. Genera y retorna un token de…, Asocia una nueva regla de acceso (ACL/RBAC) a un dispositivo (Solo…, register_device() (+5 more)

### Community 35 - "logging_config.py"
Cohesion: 0.50
Nodes (3): logging_config.py — Configuración centralizada de logging para FaceSentinel…, Configura el sistema de logging profesional. Debe llamarse UNA VEZ al iniciar…, setup_logging()

### Community 36 - "edge_gateway.py"
Cohesion: 0.15
Nodes (14): BlinkStateMachine, compute_ear(), crop_face_from_mesh(), _euclidean(), get_avg_ear(), main(), Detecta un parpadeo humano completo (ojos abiertos → cerrados → abiertos).…, Actualiza la FSM con el EAR del frame actual y el frame BGR. Retorna True… (+6 more)

### Community 37 - "button.tsx"
Cohesion: 0.67
Nodes (3): Button, ButtonProps, buttonVariants

### Community 38 - "tabs.tsx"
Cohesion: 0.50
Nodes (3): TabsContent, TabsList, TabsTrigger

### Community 39 - "TestAuthentication"
Cohesion: 0.25
Nodes (5): Tests para los endpoints de autenticación., Verifica que el antiguo endpoint biométrico POST retorne 410 (Deprecated)., Verifica que falten campos retorne 422., Verifica que credenciales incorrectas retornen 401., TestAuthentication

### Community 54 - "analyze_frequency"
Cohesion: 0.50
Nodes (3): analyze_frequency(), Analiza el espectro de frecuencia de la imagen facial. Las pantallas y las…, Verifica que el análisis de frecuencia retorna un resultado válido.

### Community 55 - "BlinkTracker"
Cohesion: 0.33
Nodes (3): BlinkTracker, Actualiza el estado con el nuevo EAR. Retorna True si se acaba de completar un…, Rastrea el historial de EAR (Eye Aspect Ratio) a través de múltiples frames…

### Community 56 - "TestRegistration"
Cohesion: 0.25
Nodes (5): Tests para el endpoint de registro de usuarios., Verifica que registrar sin credenciales de admin da 401., Verifica que registrar sin imagen da error 422., Verifica que campos vacíos son procesados., TestRegistration

### Community 57 - "change_my_password"
Cohesion: 0.17
Nodes (13): change_my_password(), enroll_my_biometrics(), get_my_client_app(), Permite a un Administrador o Desarrollador logueado cambiar su contraseña., Permite a un Desarrollador o Administrador registrar su rostro para iniciar…, Retorna la configuración de la aplicación cliente asociada al Desarrollador…, get_oauth_client(), get_user_auth_info_by_id() (+5 more)

### Community 58 - "config.py"
Cohesion: 0.28
Nodes (5): Settings, BaseSettings, main(), reset_chromadb(), reset_sqlite()

### Community 59 - "general_exception_handler"
Cohesion: 0.33
Nodes (7): general_exception_handler(), Request, Captura errores de validación y retorna un 400 limpio., Captura errores inesperados y retorna un 500 con información útil., value_error_handler(), Exception, exception_handler

### Community 60 - "get_current_user"
Cohesion: 0.40
Nodes (5): get_current_user(), Dependency de FastAPI que protege un endpoint. Acepta autenticación por JWT…, Verifica y decodifica un JWT. Args: token: El JWT a verificar Returns: Payload…, verify_token(), HTTPAuthorizationCredentials

### Community 62 - "get_client_logs"
Cohesion: 0.33
Nodes (6): get_client_logs(), Obtiene los registros de autenticación asociados a un clientId específico en la…, get_recent_records_by_client(), Consulta el historial de autenticaciones de un cliente en la blockchain. Args:…, get_local_client_logs(), Obtiene los registros de acceso locales para un cliente.

### Community 63 - "is_blockchain_available"
Cohesion: 0.13
Nodes (17): get_user_auth_history(), Consulta el historial de autenticaciones de un usuario en la blockchain (o…, get_auth_history(), get_contract_info(), is_blockchain_available(), log_authentication(), Verifica si el servicio de blockchain está disponible., Registra un evento de autenticación en la blockchain. Args: user_id:… (+9 more)

### Community 64 - "analyze_blink"
Cohesion: 0.33
Nodes (6): analyze_blink(), _euclidean_distance(), _eye_aspect_ratio(), Calcula la distancia lineal entre dos puntos espaciales., Calcula el EAR (Eye Aspect Ratio). Fórmula científica que divide la altura del…, Analiza un frame y retorna si hay un rostro y su nivel de apertura de ojos.…

### Community 65 - "websocket_liveness"
Cohesion: 0.40
Nodes (5): Endpoint interactivo que recibe frames de video en tiempo real, rastrea los…, websocket_liveness(), analyze_texture(), Analiza la textura facial para distinguir piel real de pantallas/impresiones.…, websocket

### Community 66 - "save_acl_rule"
Cohesion: 0.50
Nodes (4): Any, AccessControlList, Registra una regla de acceso (ACL/RBAC) para un dispositivo IoT., save_acl_rule()

### Community 67 - "get_devices"
Cohesion: 0.50
Nodes (4): get_devices(), Lista todos los dispositivos IoT registrados (Solo Administrador), get_all_devices(), Retorna todos los dispositivos IoT registrados.

## Knowledge Gaps
- **135 isolated node(s):** `name`, `private`, `version`, `type`, `dev` (+130 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **9 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `base64_to_image()` connect `base64_to_image` to `endpoints.py`, `websocket_liveness`, `image_processing.py`, `physical_access_authenticate`, `register_face`, `face_recognition.py`, `analyze_frequency`, `TestLiveness`, `test_recognition.py`?**
  _High betweenness centrality (0.032) - this node is a cross-community bridge._
- **Why does `get_device_by_token()` connect `physical_access_authenticate` to `endpoints.py`, `storage.py`?**
  _High betweenness centrality (0.026) - this node is a cross-community bridge._
- **Why does `comprehensive_liveness_check()` connect `comprehensive_liveness_check` to `endpoints.py`, `analyze_blink`, `websocket_liveness`, `physical_access_authenticate`, `analyze_frequency`, `TestLiveness`, `test_recognition.py`?**
  _High betweenness centrality (0.023) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `physical_access_authenticate()` (e.g. with `M2MAuthRequest` and `log_authentication()`) actually correct?**
  _`physical_access_authenticate()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `name`, `private`, `version` to the rest of the system?**
  _135 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `endpoints.py` be split into smaller, more focused modules?**
  _Cohesion score 0.13756613756613756 - nodes in this community are weakly interconnected._
- **Should `image_processing.py` be split into smaller, more focused modules?**
  _Cohesion score 0.10317460317460317 - nodes in this community are weakly interconnected._