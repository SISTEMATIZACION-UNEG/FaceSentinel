import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # API
    PROJECT_NAME: str = "FaceSentinel"
    API_V1_STR: str = "/api/v1"
    
    # Rutas
    SQLITE_DB_PATH: str = "./data/sql/database.db"
    CHROMA_DB_PATH: str = "./data/chromadb"
    TEMP_IMAGES_PATH: str = "./data/temp_images"
    
    # IA
    AI_MODEL_NAME: str = "ArcFace"
    FACE_MATCH_THRESHOLD: float = float(os.getenv("FACE_MATCH_THRESHOLD", "0.60"))
    
    # Web3
    BLOCKCHAIN_RPC_URL: str = "http://127.0.0.1:7545"
    CHAIN_ID: int = 1337
    SMART_CONTRACT_ADDRESS: str = ""
    DEVICE_PRIVATE_KEY: str = ""
    # Cuenta administradora de la blockchain (leída directamente del .env)
    ADMIN_ADDRESS: str = ""
    ADMIN_PRIVATE_KEY: str = ""

    # Seguridad — JWT
    JWT_SECRET_KEY: str = "facesentinel-super-secret-key-change-in-production"
    JWT_EXPIRATION_MINUTES: int = 1440

    # Seguridad — Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = 30

    # Seguridad M2M (Acceso Físico)
    HW_CLIENT_SECRET: str = "secret_door_01"

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        # Ignorar variables del .env que no estén definidas en esta clase
        # (ej: WEB3_PROVIDER_URI, ADMIN_ADDRESS, ADMIN_PRIVATE_KEY son leídas por otros módulos con os.getenv)
        "extra": "ignore",
    }

# Creamos una instancia global para usarla en todo el proyecto
settings = Settings()

# Crear los directorios de datos automáticamente si no existen
os.makedirs(settings.TEMP_IMAGES_PATH, exist_ok=True)
os.makedirs(os.path.dirname(settings.SQLITE_DB_PATH), exist_ok=True)
os.makedirs(settings.CHROMA_DB_PATH, exist_ok=True)